﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=ProSoft-Septembar2019;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public List<Sud> vratiSveSudove()
        {
            List<Sud> lista = new List<Sud>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Sud";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Sud s = new Sud();
                    s.Id = citac.GetInt32(0);
                    s.Naziv = citac.GetString(1);
                    s.Adresa = citac.GetString(2);
                    lista.Add(s);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<TipSpora> vratiSveTipoveSpora()
        {
            List<TipSpora> lista = new List<TipSpora>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from TipSpora";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    TipSpora s = new TipSpora();
                    s.Id = citac.GetInt32(0);
                    s.Naziv = citac.GetString(1);
                    lista.Add(s);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiIDPredmeta()
        {
            try
            {

                komanda.CommandText = "Select max(PredmetID) from Predmet";
                object o = komanda.ExecuteScalar();
                if (o == DBNull.Value) return 1;
                else return Convert.ToInt32(o);
            }
            catch (Exception)
            {

                throw;
            }
        }

        //cuvanje bool u bit
        int getBit(bool b)
        {
            if (b) return 1;
            else return 0;
        }

        public string sacuvajPredmet(Predmet p)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);
                komanda.CommandText = "Insert into Predmet (BrojPredmeta, DatumPrijema, Tuzilac, Tuzeni, PlacenaSudskaTaksa, TipSporaID, SudID, Status) values('" +p.BrojPredmeta+"','"
                    +p.DatumPrijema.ToString("yyyy-MM-dd")+"','"
                    +p.Tuzilac+"','"+p.Tuzeni+"',"+getBit(p.PlacenaSudskaTaksa)+","+p.TipSpora.Id+"," +
                    ""+p.Sud.Id+",'"+p.Status+"')";
                komanda.ExecuteNonQuery();
                p.Id = vratiIDPredmeta();

                if (!proveraJedinstvenosti(p.Id))
                {
                    transakcija.Rollback();
                    return "Nije jedinstven ID predmeta!";
                }

                foreach(Podnesak pod in p.ListaPodneska)
                {
                    komanda.CommandText = "Insert into Podnesak values(" + p.Id + "," + pod.Rb + ",'"
                        + pod.DatumPrijema.ToString("yyyy-MM-dd")+"','"+pod.Opis+"','"
                        +pod.VrstaPodneska+"')";

                    komanda.ExecuteNonQuery();
                }
                transakcija.Commit();
                return "Sacuvano!";
            }
            catch (Exception ex)
            {
                transakcija.Rollback();
                System.Windows.Forms.MessageBox.Show(ex.Message);
                return "Nije sacuvano!";
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Predmet> vratiSvePredmete()
        {
            List<Predmet> lista = new List<Predmet>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from TipSpora";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Predmet p = new Predmet();
                    citac.GetInt32(0);
                    lista.Add(p);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        private bool proveraJedinstvenosti(int id)
        {
            List<Predmet> lista = new List<Predmet>();
            lista = vratiSvePredmete();

            foreach(Predmet pt in lista)
            {
                if (pt.Id == id) return false;
            }
            return true;
        }
    }
}
