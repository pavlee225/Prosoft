﻿namespace Klijent
{
    partial class FormaKlijent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbTipSpora = new System.Windows.Forms.ComboBox();
            this.btnSacuvaj = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnObrisi = new System.Windows.Forms.Button();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.cbDa = new System.Windows.Forms.CheckBox();
            this.txtTuzeni = new System.Windows.Forms.TextBox();
            this.txtDatumPrijema = new System.Windows.Forms.TextBox();
            this.txtTuzilac = new System.Windows.Forms.TextBox();
            this.txtBrojPredmeta = new System.Windows.Forms.TextBox();
            this.cmbSud = new System.Windows.Forms.ComboBox();
            this.cbNe = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sud:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Placena taksa:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tuzeni:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tuzilac:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Datum prijema:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Broj predmeta:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Tip spora:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbNe);
            this.groupBox1.Controls.Add(this.cmbTipSpora);
            this.groupBox1.Controls.Add(this.btnSacuvaj);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.btnObrisi);
            this.groupBox1.Controls.Add(this.btnDodaj);
            this.groupBox1.Controls.Add(this.cbDa);
            this.groupBox1.Controls.Add(this.txtTuzeni);
            this.groupBox1.Controls.Add(this.txtDatumPrijema);
            this.groupBox1.Controls.Add(this.txtTuzilac);
            this.groupBox1.Controls.Add(this.txtBrojPredmeta);
            this.groupBox1.Controls.Add(this.cmbSud);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(436, 420);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Unos predmeta";
            // 
            // cmbTipSpora
            // 
            this.cmbTipSpora.FormattingEnabled = true;
            this.cmbTipSpora.Location = new System.Drawing.Point(93, 46);
            this.cmbTipSpora.Name = "cmbTipSpora";
            this.cmbTipSpora.Size = new System.Drawing.Size(337, 21);
            this.cmbTipSpora.TabIndex = 19;
            // 
            // btnSacuvaj
            // 
            this.btnSacuvaj.Location = new System.Drawing.Point(292, 384);
            this.btnSacuvaj.Name = "btnSacuvaj";
            this.btnSacuvaj.Size = new System.Drawing.Size(138, 36);
            this.btnSacuvaj.TabIndex = 18;
            this.btnSacuvaj.Text = "Sacuvaj predmet";
            this.btnSacuvaj.UseVisualStyleBackColor = true;
            this.btnSacuvaj.Click += new System.EventHandler(this.btnSacuvaj_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 242);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(421, 135);
            this.dataGridView1.TabIndex = 17;
            // 
            // btnObrisi
            // 
            this.btnObrisi.Location = new System.Drawing.Point(154, 212);
            this.btnObrisi.Name = "btnObrisi";
            this.btnObrisi.Size = new System.Drawing.Size(126, 23);
            this.btnObrisi.TabIndex = 16;
            this.btnObrisi.Text = "Obrisi podnesak";
            this.btnObrisi.UseVisualStyleBackColor = true;
            this.btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(7, 212);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(126, 23);
            this.btnDodaj.TabIndex = 15;
            this.btnDodaj.Text = "Dodaj podnesak";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // cbDa
            // 
            this.cbDa.AutoSize = true;
            this.cbDa.Location = new System.Drawing.Point(93, 189);
            this.cbDa.Name = "cbDa";
            this.cbDa.Size = new System.Drawing.Size(40, 17);
            this.cbDa.TabIndex = 13;
            this.cbDa.Text = "Da";
            this.cbDa.UseVisualStyleBackColor = true;
            // 
            // txtTuzeni
            // 
            this.txtTuzeni.Location = new System.Drawing.Point(93, 161);
            this.txtTuzeni.Name = "txtTuzeni";
            this.txtTuzeni.Size = new System.Drawing.Size(337, 20);
            this.txtTuzeni.TabIndex = 12;
            // 
            // txtDatumPrijema
            // 
            this.txtDatumPrijema.Location = new System.Drawing.Point(93, 100);
            this.txtDatumPrijema.Name = "txtDatumPrijema";
            this.txtDatumPrijema.Size = new System.Drawing.Size(337, 20);
            this.txtDatumPrijema.TabIndex = 11;
            // 
            // txtTuzilac
            // 
            this.txtTuzilac.Location = new System.Drawing.Point(93, 131);
            this.txtTuzilac.Name = "txtTuzilac";
            this.txtTuzilac.Size = new System.Drawing.Size(337, 20);
            this.txtTuzilac.TabIndex = 10;
            // 
            // txtBrojPredmeta
            // 
            this.txtBrojPredmeta.Location = new System.Drawing.Point(93, 75);
            this.txtBrojPredmeta.Name = "txtBrojPredmeta";
            this.txtBrojPredmeta.Size = new System.Drawing.Size(337, 20);
            this.txtBrojPredmeta.TabIndex = 9;
            // 
            // cmbSud
            // 
            this.cmbSud.FormattingEnabled = true;
            this.cmbSud.Location = new System.Drawing.Point(93, 16);
            this.cmbSud.Name = "cmbSud";
            this.cmbSud.Size = new System.Drawing.Size(337, 21);
            this.cmbSud.TabIndex = 7;
            // 
            // cbNe
            // 
            this.cbNe.AutoSize = true;
            this.cbNe.Location = new System.Drawing.Point(154, 187);
            this.cbNe.Name = "cbNe";
            this.cbNe.Size = new System.Drawing.Size(40, 17);
            this.cbNe.TabIndex = 20;
            this.cbNe.Text = "Ne";
            this.cbNe.UseVisualStyleBackColor = true;
            // 
            // FormaKlijent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 438);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormaKlijent";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormaKlijent_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSacuvaj;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnObrisi;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.CheckBox cbDa;
        private System.Windows.Forms.TextBox txtTuzeni;
        private System.Windows.Forms.TextBox txtDatumPrijema;
        private System.Windows.Forms.TextBox txtTuzilac;
        private System.Windows.Forms.TextBox txtBrojPredmeta;
        private System.Windows.Forms.ComboBox cmbSud;
        private System.Windows.Forms.ComboBox cmbTipSpora;
        private System.Windows.Forms.CheckBox cbNe;
    }
}

