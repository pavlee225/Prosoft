﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        Predmet p;
        public FormaKlijent()
        {
            InitializeComponent();
            
            
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }

            cmbSud.DataSource = k.vratiSudove();
            cmbTipSpora.DataSource = k.vratiTipoveSpora();
            p = new Predmet();
            dataGridView1.DataSource = p.ListaPodneska;
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            Podnesak pod = new Podnesak();
            p.ListaPodneska.Add(pod);
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                Podnesak podnesak = dataGridView1.CurrentRow.DataBoundItem as Podnesak;
                p.ListaPodneska.Remove(podnesak);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {

            try
            {
                p.Sud = cmbSud.SelectedItem as Sud;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali Sud!");
                return;
            }

            try
            {
                p.TipSpora = cmbTipSpora.SelectedItem as TipSpora;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali tip spora!");
                return;
            }

            p.BrojPredmeta = txtBrojPredmeta.Text;
            if(p.BrojPredmeta == "")
            {
                MessageBox.Show("Niste uneli broj predmeta!");
                return;
            }

            try
            {
                p.DatumPrijema = Convert.ToDateTime(txtDatumPrijema.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste dobro uneli datum!");
                return;
            }

            p.Tuzilac = txtTuzilac.Text;
            if(p.Tuzilac == "")
            {
                MessageBox.Show("Niste dobro uneli tuzioca!");
                return;
            }

            p.Tuzeni = txtTuzeni.Text;
            if (p.Tuzeni == "")
            {
                MessageBox.Show("Niste dobro uneli tuzenog!");
                return;
            }

            if(cbDa.Checked && cbNe.Checked)
            {
                MessageBox.Show("Ne mogu da budu cekirani i Da i Ne.");
                return;
            }

            if(!cbNe.Checked && !cbDa.Checked)
            {
                MessageBox.Show("Morate da cekirate ili Da ili Ne!");
                return;
            }

            if (cbDa.Checked)
            {
                p.PlacenaSudskaTaksa = true;
            }
            else
            {
                p.PlacenaSudskaTaksa = false;
            }

            p.Status = "Neresen";

            //validacije
            if(p.ListaPodneska.Count< 1)
            {
                MessageBox.Show("Predmet mora imati bar jedan podnesak!");
                return;
            }

            foreach(Podnesak podnes in p.ListaPodneska)
            {
                int i = DateTime.Compare(podnes.DatumPrijema, p.DatumPrijema);
                if (i < 0)
                {
                    MessageBox.Show("Datum podneska je pre dauma predmeta!");
                    return;
                }
            }

            string poruka = k.sacuvajPredmet(p);
            MessageBox.Show(poruka);
        }
    }
}
