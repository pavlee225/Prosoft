﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Operacije { Kraj=1,
        VratiSudove = 2,
        VratiSveTipoveSporova = 3,
        SacuvajPredmet = 4,
    }

    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public object TransferObjekat; //salje se
        public object Rezultat; //prima se
    }
}
