﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Predmet
    {
        public Predmet()
        {
            listaPodneska = new BindingList<Podnesak>();
        }

        public override string ToString()
        {
            return brojPredmeta+" ";
        }

        int id;
        string brojPredmeta;
        DateTime datumPrijema;
        string tuzilac;
        string tuzeni;
        bool placenaSudskaTaksa;
        TipSpora tipSpora;
        Sud sud;
        string status;
        BindingList<Podnesak> listaPodneska;

        public int Id { get => id; set => id = value; }
        public string BrojPredmeta { get => brojPredmeta; set => brojPredmeta = value; }
        public DateTime DatumPrijema { get => datumPrijema; set => datumPrijema = value; }
        public string Tuzilac { get => tuzilac; set => tuzilac = value; }
        public string Tuzeni { get => tuzeni; set => tuzeni = value; }
        public bool PlacenaSudskaTaksa { get => placenaSudskaTaksa; set => placenaSudskaTaksa = value; }
        public TipSpora TipSpora { get => tipSpora; set => tipSpora = value; }
        public Sud Sud { get => sud; set => sud = value; }
        public string Status { get => status; set => status = value; }
        public BindingList<Podnesak> ListaPodneska { get => listaPodneska; set => listaPodneska = value; }
    }
}
