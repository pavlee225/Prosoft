﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Podnesak
    {
        public override string ToString()
        {
            return rb+" ";
        }

        int rb;
        DateTime datumPrijema;
        string opis;
        string vrstaPodneska;

        [DisplayName("RB")]
        public int Rb { get => rb; set => rb = value; }
        [DisplayName("Datum prijema")]
        public DateTime DatumPrijema { get => datumPrijema; set => datumPrijema = value; }
        public string Opis { get => opis; set => opis = value; }
        [DisplayName("Vrsta podneska")]
        public string VrstaPodneska { get => vrstaPodneska; set => vrstaPodneska = value; }
    }
}
