﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class IzmenaRasporeda : Form
    {
        private Raspored r;
        private Komunikacija k;
        private BindingList<Raspored> listaRasporeda;

        public IzmenaRasporeda()
        {
            
        }

        public IzmenaRasporeda(Raspored r, Komunikacija k, BindingList<Raspored> listaRasporeda)
        {
            InitializeComponent();
            this.r = r;
            this.k = k;
            this.listaRasporeda = listaRasporeda;
        }

        private void IzmenaRasporeda_Load(object sender, EventArgs e)
        {
            cmbEmisija.DataSource = k.vratiSveEmisije();
            cmbVoditelj.DataSource = k.vratiSveVoditelje();

            txtDatumDO.Text = r.DatumVremeDo.ToString("dd.MM.yyyy HH:mm");
            txtDatumOD.Text = r.DatumVremeOD.ToString("dd.MM.yyyy HH:mm");
            txtNapomena.Text = r.Napomena;
            cmbEmisija.Text = r.Emisija.ToString();
            cmbVoditelj.Text = r.Voditelj.ToString();
        }

        private void btnIzmeni_Click(object sender, EventArgs e)
        {
            Raspored ra = new Raspored();

            ra.Napomena = txtNapomena.Text;

            try
            {
                ra.DatumVremeOD = DateTime.ParseExact(txtDatumOD.Text, "dd.MM.yyyy HH:mm", null);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije validan datum!");
                return;
            }

            try
            {
                ra.DatumVremeDo = DateTime.ParseExact(txtDatumDO.Text, "dd.MM.yyyy HH:mm", null);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije validan datum!");
                return;
            }

            ra.Emisija = cmbEmisija.SelectedItem as Emisija;
            if(ra.Emisija == null)
            {
                MessageBox.Show("Fali emisija!");
                return;
            }

            ra.Voditelj = cmbVoditelj.SelectedItem as Voditelj;
            if(ra.Voditelj == null)
            {
                MessageBox.Show("Fali voditelj!");
                return;
            }

            //ne mogu dve emisije isti dan 
            foreach(Raspored ras in listaRasporeda)
            {
                if(ra.Emisija.Id == ras.Emisija.Id && ra.DatumVremeDo.Date == ras.DatumVremeDo.Date && ras.Status != Status.Obrisan)
                {
                    MessageBox.Show("Vec ima ta emisija istog dana!");
                    return;
                }
            }

            //reditelj 3 snimanja u toku dana
            int br = 1;
            foreach(Raspored ras in listaRasporeda)
            {
                if(ra.DatumVremeDo.Date == ras.DatumVremeDo.Date && ras.Status != Status.Obrisan)
                {
                    br++;
                }
            }
            if (br > 3)
            {
                MessageBox.Show("Mnogo ti je za danas!");
                return;
            }

            //voditelj 2 snimanja u toku dana
            br = 1;
            foreach(Raspored ras in listaRasporeda)
            {
                if(ra.DatumVremeDo.Date == ras.DatumVremeDo.Date && ra.Voditelj.Id == ras.Voditelj.Id && ras.Status!= Status.Obrisan)
                {
                    br++;
                }
            }
            if (br > 2)
            {
                MessageBox.Show("Menjaj voditelja!");
                return;
            }

            r.Napomena = ra.Napomena;
            r.Voditelj = ra.Voditelj;
            r.Emisija = ra.Emisija;
            r.DatumVremeDo = ra.DatumVremeDo;
            r.DatumVremeOD = ra.DatumVremeOD;
            if (r.Status != Status.Dodat) r.Status = Status.Izmenjen;
            this.Close();
        }
    }
}
