﻿namespace Klijent
{
    partial class IzmenaRasporeda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDatumOD = new System.Windows.Forms.TextBox();
            this.txtNapomena = new System.Windows.Forms.TextBox();
            this.txtDatumDO = new System.Windows.Forms.TextBox();
            this.cmbVoditelj = new System.Windows.Forms.ComboBox();
            this.cmbEmisija = new System.Windows.Forms.ComboBox();
            this.btnIzmeni = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Datum vreme OD:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Napomena:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Emisija:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Voditelj:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Datum vreme DO:";
            // 
            // txtDatumOD
            // 
            this.txtDatumOD.Location = new System.Drawing.Point(151, 15);
            this.txtDatumOD.Name = "txtDatumOD";
            this.txtDatumOD.Size = new System.Drawing.Size(235, 20);
            this.txtDatumOD.TabIndex = 5;
            // 
            // txtNapomena
            // 
            this.txtNapomena.Location = new System.Drawing.Point(151, 147);
            this.txtNapomena.Multiline = true;
            this.txtNapomena.Name = "txtNapomena";
            this.txtNapomena.Size = new System.Drawing.Size(235, 93);
            this.txtNapomena.TabIndex = 6;
            // 
            // txtDatumDO
            // 
            this.txtDatumDO.Location = new System.Drawing.Point(151, 44);
            this.txtDatumDO.Name = "txtDatumDO";
            this.txtDatumDO.Size = new System.Drawing.Size(235, 20);
            this.txtDatumDO.TabIndex = 7;
            // 
            // cmbVoditelj
            // 
            this.cmbVoditelj.FormattingEnabled = true;
            this.cmbVoditelj.Location = new System.Drawing.Point(151, 72);
            this.cmbVoditelj.Name = "cmbVoditelj";
            this.cmbVoditelj.Size = new System.Drawing.Size(235, 21);
            this.cmbVoditelj.TabIndex = 8;
            // 
            // cmbEmisija
            // 
            this.cmbEmisija.FormattingEnabled = true;
            this.cmbEmisija.Location = new System.Drawing.Point(151, 106);
            this.cmbEmisija.Name = "cmbEmisija";
            this.cmbEmisija.Size = new System.Drawing.Size(235, 21);
            this.cmbEmisija.TabIndex = 9;
            // 
            // btnIzmeni
            // 
            this.btnIzmeni.Location = new System.Drawing.Point(39, 254);
            this.btnIzmeni.Name = "btnIzmeni";
            this.btnIzmeni.Size = new System.Drawing.Size(347, 38);
            this.btnIzmeni.TabIndex = 10;
            this.btnIzmeni.Text = "Izmeni";
            this.btnIzmeni.UseVisualStyleBackColor = true;
            this.btnIzmeni.Click += new System.EventHandler(this.btnIzmeni_Click);
            // 
            // IzmenaRasporeda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 304);
            this.Controls.Add(this.btnIzmeni);
            this.Controls.Add(this.cmbEmisija);
            this.Controls.Add(this.cmbVoditelj);
            this.Controls.Add(this.txtDatumDO);
            this.Controls.Add(this.txtNapomena);
            this.Controls.Add(this.txtDatumOD);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "IzmenaRasporeda";
            this.Text = "IzmenaRasporeda";
            this.Load += new System.EventHandler(this.IzmenaRasporeda_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDatumOD;
        private System.Windows.Forms.TextBox txtNapomena;
        private System.Windows.Forms.TextBox txtDatumDO;
        private System.Windows.Forms.ComboBox cmbVoditelj;
        private System.Windows.Forms.ComboBox cmbEmisija;
        private System.Windows.Forms.Button btnIzmeni;
    }
}