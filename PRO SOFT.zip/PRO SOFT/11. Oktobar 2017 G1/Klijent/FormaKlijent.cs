﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        BindingList<Raspored> listaRasporeda;
        public FormaKlijent()
        {
            InitializeComponent();
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }
        }

        private void FormaKlijent_FormClosed(object sender, FormClosedEventArgs e)
        {
            k.kraj();
        }

        private void btnPrikazRasporeda_Click(object sender, EventArgs e)
        {
            Reziser r = new Reziser();
            r.KorisnickoIme = txtUsernameReditelja.Text;

            listaRasporeda = new BindingList<Raspored>(k.vratiRasporede(r));
            dataGridView1.DataSource = listaRasporeda;
        }

        private void btnObrisiRaspored_Click(object sender, EventArgs e)
        {
            try
            {
                Raspored r = dataGridView1.CurrentRow.DataBoundItem as Raspored;
                if (r.Status != Status.Dodat) r.Status = Status.Obrisan;
                else listaRasporeda.Remove(r); //ako je dodata stavka, samo je ukloniti jer nje svakako nema u bazi

            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali!");
            }
        }

        private void btnIzmenaRasporeda_Click(object sender, EventArgs e)
        {
            try
            {
                Raspored r = dataGridView1.CurrentRow.DataBoundItem as Raspored;
                new IzmenaRasporeda(r, k, listaRasporeda).ShowDialog();
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali!");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            if(k.sacuvajIzmene(new List<Raspored>(listaRasporeda)))
            {
                MessageBox.Show("Sve ok!");
                btnPrikazRasporeda_Click(sender, e);
            }
            else
            {
                MessageBox.Show("Nije!");
            }
        }
    }
}
