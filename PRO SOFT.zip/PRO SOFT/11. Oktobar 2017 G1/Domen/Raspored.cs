﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Status { NijeMenjano, Dodat, Izmenjen, Obrisan}
    [Serializable]
    public class Raspored
    {
        int id;
        DateTime datumVremeOD;
        DateTime datumVremeDo;
        string napomena;
        Voditelj voditelj;
        Emisija emisija;
        Reziser reziser;

        Status status;

        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        public DateTime DatumVremeOD { get => datumVremeOD; set => datumVremeOD = value; }
        public DateTime DatumVremeDo { get => datumVremeDo; set => datumVremeDo = value; }
        public string Napomena { get => napomena; set => napomena = value; }
        public Voditelj Voditelj { get => voditelj; set => voditelj = value; }
        public Emisija Emisija { get => emisija; set => emisija = value; }
        public Reziser Reziser { get => reziser; set => reziser = value; }
        public Status Status { get => status; set => status = value; }
    }
}
