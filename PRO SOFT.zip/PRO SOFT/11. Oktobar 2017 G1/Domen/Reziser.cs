﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Reziser
    {
        public override string ToString()
        {
            return ime+" "+prezime;
        }

        int id;
        string ime;
        string prezime;
        string specijalnost;
        string korisnickoIme;

        public int Id { get => id; set => id = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string Specijalnost { get => specijalnost; set => specijalnost = value; }
        public string KorisnickoIme { get => korisnickoIme; set => korisnickoIme = value; }
    }
}
