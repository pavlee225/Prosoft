﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class KlasaZaServer
    {
        string emisija;
        string voditelj;
        int brSati;
        int gledanost;

        public string Emisija { get => emisija; set => emisija = value; }
        public string Voditelj { get => voditelj; set => voditelj = value; }
        public int BrSati { get => brSati; set => brSati = value; }
        public int Gledanost { get => gledanost; set => gledanost = value; }
    }
}
