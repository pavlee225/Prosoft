﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction tramsakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Oktobar2017G1;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public List<Raspored> vratiRasporedeZaRezisere(Reziser r)
        {
            List<Raspored> lista = new List<Raspored>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Raspored r inner join Emisija e on r.EmisijaID=e.EmisijaID inner join Voditelj v on r.VoditeljID=v.VoditeljID inner join Reditelj re on r.RediteljID=re.RediteljID where re.KorisnickoIme='" + r.KorisnickoIme + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Raspored ra = new Raspored();
                    ra.Id = citac.GetInt32(0);
                    ra.DatumVremeOD = citac.GetDateTime(1);
                    ra.DatumVremeDo = citac.GetDateTime(2);
                    ra.Napomena = citac.GetString(3);
                    ra.Voditelj = new Voditelj();
                    ra.Voditelj.Id = citac.GetInt32(10);
                    ra.Voditelj.Ime = citac.GetString(11);
                    ra.Voditelj.Prezime = citac.GetString(12);
                    ra.Voditelj.StrucnaSprema = citac.GetString(13);
                    ra.Emisija = new Emisija();
                    ra.Emisija.Id = citac.GetInt32(7);
                    ra.Emisija.Naziv = citac.GetString(8);
                    ra.Emisija.Opis = citac.GetString(9);
                    ra.Reziser = new Reziser();
                    ra.Reziser.Id = citac.GetInt32(14);
                    ra.Reziser.Ime = citac.GetString(15);
                    ra.Reziser.Prezime = citac.GetString(16);
                    ra.Reziser.Specijalnost = citac.GetString(17);
                    ra.Reziser.KorisnickoIme = citac.GetString(18);

                    lista.Add(ra);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Voditelj> vratiSveVoditelje()
        {
            List<Voditelj> lista = new List<Voditelj>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Voditelj";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Voditelj v = new Voditelj();
                    v.Id = citac.GetInt32(0);
                    v.Ime = citac.GetString(1);
                    v.Prezime = citac.GetString(2);
                    v.StrucnaSprema = citac.GetString(3);

                    lista.Add(v);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Emisija> vratiSveEmisije()
        {
            List<Emisija> lista = new List<Emisija>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Emisija";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Emisija v = new Emisija();
                    v.Id = citac.GetInt32(0);
                    v.Naziv = citac.GetString(1);
                    v.Opis = citac.GetString(2);

                    lista.Add(v);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool sacuvajIzmene(List<Raspored> lista)
        {
            try
            {
                konekcija.Open();
                tramsakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, tramsakcija);

                foreach(Raspored r in lista)
                {
                    switch (r.Status)
                    {
                        case Status.NijeMenjano:
                            break;
                        case Status.Dodat:
                            break;
                        case Status.Izmenjen:
                            komanda.CommandText = "Update Raspored set DatumVremeOD='"+r.DatumVremeOD.ToString("yyyy-MM-dd HH:mm")+"', DatumVremeDO='"+ r.DatumVremeOD.ToString("yyyy-MM-dd HH:mm") + "', Napomena='"+r.Napomena+"', EmisijaID="+r.Emisija.Id+",VoditeljID="+r.Voditelj.Id + " where ID =" + r.Id + "";
                            komanda.ExecuteNonQuery();
                            break;
                        case Status.Obrisan:
                            komanda.CommandText = "Delete from Raspored where ID=" + r.Id + "";
                            komanda.ExecuteNonQuery();
                            break;
                    }
                }
                tramsakcija.Commit();
                return true;
            }
            catch (Exception)
            {
                tramsakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<KlasaZaServer> vratiZaServer(string uslov)
        {
            List<KlasaZaServer> lista = new List<KlasaZaServer>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select e.Naziv, v.Ime, v.Prezime, sum(DATEDIFF(hour, DatumVremeOD, DatumVremeDO)) as BR from Raspored r inner join Emisija e on r.EmisijaID=e.EmisijaID inner join Voditelj v on r.VoditeljID=v.VoditeljID"+uslov+"group by e.Naziv, v.Ime, v.Prezime order by BR desc";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    KlasaZaServer k = new KlasaZaServer();
                    k.Emisija = citac.GetString(0);
                    k.Voditelj = citac.GetString(1) + " " + citac.GetString(2);
                    try
                    {
                        k.BrSati = Convert.ToInt32(citac.GetValue(3));
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                    k.Gledanost = k.BrSati * 10;

                    lista.Add(k);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
