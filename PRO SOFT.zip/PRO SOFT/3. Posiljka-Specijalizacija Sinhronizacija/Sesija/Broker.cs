﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Biblioteka;
using System.Data;
using System.Data.SqlClient;

namespace Sesija
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Posiljka;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        // metoda
        public List<Korisnik> vratiSveKorisnike()
        {
            List<Korisnik> lista = new List<Korisnik>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Korisnik k inner join FizickoLice f on k.ID = f.ID";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    FizickoLice f = new FizickoLice();
                    f.Id = citac.GetInt32(0);
                    f.Adresa = citac.GetString(1);
                    f.Ime = citac.GetString(3);
                    f.Prezime = citac.GetString(4);
                    lista.Add(f);
                }
                citac.Close();

                komanda.CommandText = "Select * from Korisnik k inner join PravnoLice f on k.ID = f.ID";
                citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    PravnoLice p = new PravnoLice();
                    p.Id = citac.GetInt32(0);
                    p.Adresa = citac.GetString(1);
                    p.Naziv = citac.GetString(3);
                    lista.Add(p);
                }
                citac.Close();

                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiSifru()
        {
            try
            {
                komanda.CommandText = "Select max(ID) from Posiljka1";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {
                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //cuvanje bool
        int getBit(bool b)
        {
            if (b) return 1; //true
            else return 0; //false
        }


        public void sacuvajPosiljke(List<Posiljka> lista)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija,transakcija);

                foreach(Posiljka p in lista)
                {
                    switch (p.Status)
                    {
                        case Status.Dodata:
                            p.Id = vratiSifru();
                            komanda.CommandText = "Insert into Posiljka1 values(" + p.Id + "," + getBit(p.Hitno) + "," + p.Posiljalac.Id + "," + p.Primalac.Id + ")";
                            komanda.ExecuteNonQuery();
                            break;
                        case Status.Izmenjena:
                            komanda.CommandText = "Update Posiljka1 set Hitno="+getBit(p.Hitno) + ", PosiljalacID=" + p.Posiljalac.Id + ", PrimalacID=" + p.Primalac.Id +"where ID="+p.Id+"";
                            komanda.ExecuteNonQuery();
                            break;
                        case Status.Obrisana:
                            komanda.CommandText = "Delete from Posiljka1 where ID=" + p.Id + "";
                            komanda.ExecuteNonQuery();
                            break;
                        default:
                            break;
                    }
                    
                }
                transakcija.Commit();
            }
            catch (Exception)
            {
                transakcija.Rollback();
                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Posiljka> vratiSvePosiljke()
        {
            List<Posiljka> lista = new List<Posiljka>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Posiljka1 p";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Posiljka p = new Posiljka();
                    p.Id = citac.GetInt32(0);
                    p.Hitno = citac.GetBoolean(1);
                    p.Posiljalac = new Korisnik();
                    p.Posiljalac.Id = citac.GetInt32(2);
                    p.Primalac = new Korisnik();
                    p.Primalac.Id = citac.GetInt32(3);
                    lista.Add(p);
                }
                citac.Close();

                foreach(Posiljka p in lista)
                {
                    p.Posiljalac = pronadjiKorisnika(p.Posiljalac);
                    p.Primalac = pronadjiKorisnika(p.Primalac);
                }

                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public Korisnik pronadjiKorisnika(Korisnik k)
        {
            try
            {
                //Nema potrebe otvarati konekciju.
                komanda.CommandText = "Select * from Korisnik k inner join FizickoLice f on k.ID = f.ID where k.ID="+k.Id+"";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    FizickoLice f = new FizickoLice();
                    f.Id = citac.GetInt32(0);
                    f.Adresa = citac.GetString(1);
                    f.Ime = citac.GetString(3);
                    f.Prezime = citac.GetString(4);
                    //Korinsik je fizicko lice.
                    citac.Close();
                    return f;
                }
                citac.Close();

                komanda.CommandText = "Select * from Korisnik k inner join PravnoLice f on k.ID = f.ID where k.ID=" + k.Id+"";
                citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    PravnoLice p = new PravnoLice();
                    p.Id = citac.GetInt32(0);
                    p.Adresa = citac.GetString(1);
                    p.Naziv = citac.GetString(3);
                    //Korisnik je pravno lice.
                    citac.Close();
                    return p;
                }
                citac.Close();

                return null;
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
