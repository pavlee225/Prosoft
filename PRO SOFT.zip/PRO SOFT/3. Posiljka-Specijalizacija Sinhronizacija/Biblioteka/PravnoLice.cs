﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class PravnoLice:Korisnik
    {
        public override string ToString()
        {
            return naziv;
        }

        string naziv;

        public string Naziv { get => naziv; set => naziv = value; }
    }
}
