﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public enum Status { NijeMenjano, Dodata, Izmenjena, Obrisana}

    public class Posiljka
    {
        int id;
        bool hitno;
        Korisnik posiljalac;
        Korisnik primalac;
        Status status;

        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        public bool Hitno { get => hitno; set => hitno = value; }
        public Korisnik Posiljalac { get => posiljalac; set => posiljalac = value; }
        public Korisnik Primalac { get => primalac; set => primalac = value; }
        [Browsable(false)]
        public Status Status { get => status; set => status = value; }
    }
}
