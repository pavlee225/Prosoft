﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class Korisnik
    {
        protected int id;
        protected string adresa;

        public int Id { get => id; set => id = value; }
        public string Adresa { get => adresa; set => adresa = value; }

        public Korisnik Objekat
        {
            get { return this; }
        }

        public string Prikaz
        {
            get { return this.ToString(); }
        }
    }
}
