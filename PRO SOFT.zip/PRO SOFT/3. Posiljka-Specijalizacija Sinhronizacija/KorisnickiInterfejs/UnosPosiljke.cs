﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteka;
using Sesija;

namespace KorisnickiInterfejs
{
    public partial class UnosPosiljke : Form
    {
        private BindingList<Posiljka> listaPosiljki;

        public UnosPosiljke()
        {
            InitializeComponent();
        }

        public UnosPosiljke(BindingList<Posiljka> listaPosiljki)
        {
            InitializeComponent();
            this.listaPosiljki = listaPosiljki;
        }

        private void UnosPosiljke_Load(object sender, EventArgs e)
        {
            cmbPosiljalac.DataSource = Broker.dajSesiju().vratiSveKorisnike();
            cmbPrimaoc.DataSource = Broker.dajSesiju().vratiSveKorisnike();
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            Posiljka p = new Posiljka();
            p.Status = Status.Dodata;

            p.Posiljalac = cmbPosiljalac.SelectedItem as Korisnik;
            if(p.Posiljalac == null)
            {
                MessageBox.Show("Niste odabrali posiljaoca!");
                cmbPosiljalac.Focus();
                return;
            }

            p.Primalac = cmbPrimaoc.SelectedItem as Korisnik;
            if(p.Primalac == null)
            {
                MessageBox.Show("Niste odabrali primaoca!");
                cmbPrimaoc.Focus();
                return;
            }

            p.Hitno = cbHitno.Checked;

            listaPosiljki.Add(p);
            this.Close();
        }
    }
}
