﻿namespace KorisnickiInterfejs
{
    partial class UnosPosiljke
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbHitno = new System.Windows.Forms.CheckBox();
            this.cmbPosiljalac = new System.Windows.Forms.ComboBox();
            this.cmbPrimaoc = new System.Windows.Forms.ComboBox();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Posiljaoc:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Primaoc:";
            // 
            // cbHitno
            // 
            this.cbHitno.AutoSize = true;
            this.cbHitno.Location = new System.Drawing.Point(238, 79);
            this.cbHitno.Name = "cbHitno";
            this.cbHitno.Size = new System.Drawing.Size(51, 17);
            this.cbHitno.TabIndex = 2;
            this.cbHitno.Text = "Hitno";
            this.cbHitno.UseVisualStyleBackColor = true;
            // 
            // cmbPosiljalac
            // 
            this.cmbPosiljalac.FormattingEnabled = true;
            this.cmbPosiljalac.Location = new System.Drawing.Point(84, 20);
            this.cmbPosiljalac.Name = "cmbPosiljalac";
            this.cmbPosiljalac.Size = new System.Drawing.Size(205, 21);
            this.cmbPosiljalac.TabIndex = 3;
            // 
            // cmbPrimaoc
            // 
            this.cmbPrimaoc.FormattingEnabled = true;
            this.cmbPrimaoc.Location = new System.Drawing.Point(84, 52);
            this.cmbPrimaoc.Name = "cmbPrimaoc";
            this.cmbPrimaoc.Size = new System.Drawing.Size(205, 21);
            this.cmbPrimaoc.TabIndex = 4;
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(94, 114);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(195, 31);
            this.btnDodaj.TabIndex = 5;
            this.btnDodaj.Text = "Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // UnosPosiljke
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 166);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.cmbPrimaoc);
            this.Controls.Add(this.cmbPosiljalac);
            this.Controls.Add(this.cbHitno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UnosPosiljke";
            this.Text = "UnosPosiljke";
            this.Load += new System.EventHandler(this.UnosPosiljke_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cbHitno;
        private System.Windows.Forms.ComboBox cmbPosiljalac;
        private System.Windows.Forms.ComboBox cmbPrimaoc;
        private System.Windows.Forms.Button btnDodaj;
    }
}