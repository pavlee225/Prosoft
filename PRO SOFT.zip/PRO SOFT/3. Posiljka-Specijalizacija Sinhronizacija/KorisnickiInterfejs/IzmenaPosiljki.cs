﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteka;
using Sesija;

namespace KorisnickiInterfejs
{
    public partial class IzmenaPosiljki : Form
    {
        private Posiljka p;
        private BindingList<Posiljka> listaPosiljki;

        public IzmenaPosiljki()
        {
            
        }

        public IzmenaPosiljki(Posiljka p, BindingList<Posiljka> listaPosiljki)
        {
            InitializeComponent();
            this.p = p;
            this.listaPosiljki = listaPosiljki;
        }

        private void IzmenaPosiljki_Load(object sender, EventArgs e)
        {
            cmbPosiljalac.DataSource = Broker.dajSesiju().vratiSveKorisnike();
            cmbPrimaoc.DataSource = Broker.dajSesiju().vratiSveKorisnike();

            cmbPosiljalac.Text = p.Posiljalac.ToString();
            cmbPrimaoc.Text = p.Primalac.ToString();
            cbHitno.Checked = p.Hitno;
        }

        private void btnIzmeni_Click(object sender, EventArgs e)
        {
            Posiljka po = new Posiljka();
            po.Status = Status.Dodata;

            po.Posiljalac = cmbPosiljalac.SelectedItem as Korisnik;
            if (po.Posiljalac == null)
            {
                MessageBox.Show("Niste odabrali posiljaoca!");
                cmbPosiljalac.Focus();
                return;
            }

            po.Primalac = cmbPrimaoc.SelectedItem as Korisnik;
            if (po.Primalac == null)
            {
                MessageBox.Show("Niste odabrali primaoca!");
                cmbPrimaoc.Focus();
                return;
            }

            po.Hitno = cbHitno.Checked;

            p.Posiljalac = po.Posiljalac;
            p.Primalac = po.Primalac;
            p.Hitno = po.Hitno;
            if (p.Status != Status.Dodata)
            {
                p.Status = Status.Izmenjena;
            }
            this.Close();
        }
    }
}
