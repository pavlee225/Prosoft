﻿namespace KorisnickiInterfejs
{
    partial class IzmenaPosiljki
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIzmeni = new System.Windows.Forms.Button();
            this.cmbPrimaoc = new System.Windows.Forms.ComboBox();
            this.cmbPosiljalac = new System.Windows.Forms.ComboBox();
            this.cbHitno = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIzmeni
            // 
            this.btnIzmeni.Location = new System.Drawing.Point(89, 117);
            this.btnIzmeni.Name = "btnIzmeni";
            this.btnIzmeni.Size = new System.Drawing.Size(195, 31);
            this.btnIzmeni.TabIndex = 11;
            this.btnIzmeni.Text = "Izmeni";
            this.btnIzmeni.UseVisualStyleBackColor = true;
            this.btnIzmeni.Click += new System.EventHandler(this.btnIzmeni_Click);
            // 
            // cmbPrimaoc
            // 
            this.cmbPrimaoc.FormattingEnabled = true;
            this.cmbPrimaoc.Location = new System.Drawing.Point(79, 55);
            this.cmbPrimaoc.Name = "cmbPrimaoc";
            this.cmbPrimaoc.Size = new System.Drawing.Size(205, 21);
            this.cmbPrimaoc.TabIndex = 10;
            // 
            // cmbPosiljalac
            // 
            this.cmbPosiljalac.FormattingEnabled = true;
            this.cmbPosiljalac.Location = new System.Drawing.Point(79, 23);
            this.cmbPosiljalac.Name = "cmbPosiljalac";
            this.cmbPosiljalac.Size = new System.Drawing.Size(205, 21);
            this.cmbPosiljalac.TabIndex = 9;
            // 
            // cbHitno
            // 
            this.cbHitno.AutoSize = true;
            this.cbHitno.Location = new System.Drawing.Point(233, 82);
            this.cbHitno.Name = "cbHitno";
            this.cbHitno.Size = new System.Drawing.Size(51, 17);
            this.cbHitno.TabIndex = 8;
            this.cbHitno.Text = "Hitno";
            this.cbHitno.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Primaoc:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Posiljaoc:";
            // 
            // IzmenaPosiljki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 179);
            this.Controls.Add(this.btnIzmeni);
            this.Controls.Add(this.cmbPrimaoc);
            this.Controls.Add(this.cmbPosiljalac);
            this.Controls.Add(this.cbHitno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "IzmenaPosiljki";
            this.Text = "IzmenaPosiljki";
            this.Load += new System.EventHandler(this.IzmenaPosiljki_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIzmeni;
        private System.Windows.Forms.ComboBox cmbPrimaoc;
        private System.Windows.Forms.ComboBox cmbPosiljalac;
        private System.Windows.Forms.CheckBox cbHitno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}