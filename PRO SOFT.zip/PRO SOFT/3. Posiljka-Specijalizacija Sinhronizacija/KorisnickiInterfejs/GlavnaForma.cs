﻿using Biblioteka;
using Sesija;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class GlavnaForma : Form
    {
        BindingList<Posiljka> listaPosiljki;

        public GlavnaForma()
        {
            InitializeComponent();
        }

        void popuniGrid()
        {
            DataGridViewComboBoxColumn posiljalac = new DataGridViewComboBoxColumn();
            DataGridViewComboBoxColumn primalac = new DataGridViewComboBoxColumn();
            DataGridViewCheckBoxColumn hitno = new DataGridViewCheckBoxColumn();
            //DataGridViewTextBoxColumn - za tekst

            posiljalac.HeaderText = "Posiljalac";
            posiljalac.DataPropertyName = "Posiljalac"; // povezivanje cmb sa property-jem
            posiljalac.DataSource = Broker.dajSesiju().vratiSveKorisnike();
            posiljalac.ValueMember = "Objekat"; //metoda iz klase
            posiljalac.DisplayMember = "Prikaz";

            primalac.HeaderText = "Primalac";
            primalac.DataPropertyName = "Primalac";
            primalac.DataSource = Broker.dajSesiju().vratiSveKorisnike();
            primalac.ValueMember = "Objekat";
            primalac.DisplayMember = "Prikaz";

            hitno.HeaderText = "Hitno";
            hitno.DataPropertyName = "Hitno";

            dataGridView1.Columns.Add(posiljalac);
            dataGridView1.Columns.Add(primalac);
            dataGridView1.Columns.Add(hitno);

            dataGridView1.AutoGenerateColumns = false;
            listaPosiljki = new BindingList<Posiljka>();
            dataGridView1.DataSource = listaPosiljki;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Specijalizacija:
            //popuniGrid();

            //Sinhronizacija:
            listaPosiljki = new BindingList<Posiljka>(Broker.dajSesiju().vratiSvePosiljke());
            dataGridView1.DataSource = listaPosiljki;
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            try
            {
                Posiljka p = dataGridView1.CurrentRow.DataBoundItem as Posiljka;
                listaPosiljki.Remove(p);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali!");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                Broker.dajSesiju().sacuvajPosiljke(new List<Posiljka>(listaPosiljki));
                MessageBox.Show("Sacuvano!");
                // osvezavanje forme!
                Form1_Load(sender, e);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije sacuvano!");
            }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            listaPosiljki.Add(new Posiljka());
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                Posiljka p = dataGridView1.CurrentRow.DataBoundItem as Posiljka;
                if(p.Status!= Status.Dodata)
                {
                    p.Status = Status.Obrisana;
                }
                else
                {
                    listaPosiljki.Remove(p);
                }
                //dataGridView1.Refresh();
                obojiGrid();
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali!");
            }
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            new UnosPosiljke(listaPosiljki).ShowDialog();
            //dataGridView1.Refresh();
            obojiGrid();
        }

        private void btnIzmeni_Click(object sender, EventArgs e)
        {
            try
            {
                Posiljka p = dataGridView1.CurrentRow.DataBoundItem as Posiljka;
                new IzmenaPosiljki(p, listaPosiljki).ShowDialog();
                //dataGridView1.Refresh();
                obojiGrid();
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali!");
            }
        }

        void obojiGrid()
        {
            foreach(DataGridViewRow red in dataGridView1.Rows)
            {
                try
                {
                    Posiljka p = red.DataBoundItem as Posiljka;
                    switch (p.Status)
                    {
                        case Status.NijeMenjano:
                            break;
                        case Status.Dodata:
                            red.DefaultCellStyle.BackColor = Color.Aqua;
                            break;
                        case Status.Izmenjena:
                            red.DefaultCellStyle.BackColor = Color.LightGreen;
                            break;
                        case Status.Obrisana:
                            red.DefaultCellStyle.BackColor = Color.Red;
                            break;
                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                dataGridView1.Refresh();
            }
            
        }
    }
}
