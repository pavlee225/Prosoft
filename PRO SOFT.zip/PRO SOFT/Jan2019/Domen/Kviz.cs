﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Kviz
    {

        public override string ToString()
        {
            return naziv;
        }

        int id;
        string naziv;
        DateTime datumVremePocetka;
        DateTime datumVremeKraja;
        string pobednik;
      

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Naziv
        {
            get
            {
                return naziv;
            }

            set
            {
                naziv = value;
            }
        }

        public DateTime DatumVremePocetka
        {
            get
            {
                return datumVremePocetka;
            }

            set
            {
                datumVremePocetka = value;
            }
        }

        public DateTime DatumVremeKraja
        {
            get
            {
                return datumVremeKraja;
            }

            set
            {
                datumVremeKraja = value;
            }
        }

        public string Pobednik
        {
            get
            {
                return pobednik;
            }

            set
            {
                pobednik = value;
            }
        }
    }
}
