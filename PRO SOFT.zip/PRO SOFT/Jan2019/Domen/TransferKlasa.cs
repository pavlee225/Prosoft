﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Operacije { Kraj=1,
        PosaljiPoruku = 2
    }
    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public Igrac Igrac;
        public string Poruka;
        public bool Ulogovan;
        public string Pitanje;
        public string Odgovor;
        public double UkBrPoena;
        public bool NovoPitanje;
        public bool Kraj;

    }
}
