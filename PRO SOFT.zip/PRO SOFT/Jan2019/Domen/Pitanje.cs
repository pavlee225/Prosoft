﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Pitanje
    {
        int id;
        string pitanjeText;
        string odgovor;
        int brPoena;
        Kviz kviz;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string PitanjeText
        {
            get
            {
                return pitanjeText;
            }

            set
            {
                pitanjeText = value;
            }
        }

        public string Odgovor
        {
            get
            {
                return odgovor;
            }

            set
            {
                odgovor = value;
            }
        }

        public int BrPoena
        {
            get
            {
                return brPoena;
            }

            set
            {
                brPoena = value;
            }
        }

        public Kviz Kviz
        {
            get
            {
                return kviz;
            }

            set
            {
                kviz = value;
            }
        }
    }
}
