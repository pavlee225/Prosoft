﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Igrac
    {
        public override bool Equals(object obj)
        {
            var v = obj as Igrac;
            return (v != null && v.username == this.username) ;
        }

        string username;
        int brTacnih;
        int brNetacnih;
        double ukupnoPoena;

        public string Username
        {
            get
            {
                return username;
            }

            set
            {
                username = value;
            }
        }

        public int BrTacnih
        {
            get
            {
                return brTacnih;
            }

            set
            {
                brTacnih = value;
            }
        }

        public int BrNetacnih
        {
            get
            {
                return brNetacnih;
            }

            set
            {
                brNetacnih = value;
            }
        }

        public double UkupnoPoena
        {
            get
            {
                return ukupnoPoena;
            }

            set
            {
                ukupnoPoena = value;
            }
        }
    }
}
