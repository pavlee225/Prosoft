﻿namespace Klijent
{
    partial class FormKlijent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOdgovor = new System.Windows.Forms.Button();
            this.txtPoeni = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPorukaSer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtOdgovor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPitanje = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPrijava = new System.Windows.Forms.Button();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnOdgovor
            // 
            this.btnOdgovor.Enabled = false;
            this.btnOdgovor.Location = new System.Drawing.Point(177, 182);
            this.btnOdgovor.Name = "btnOdgovor";
            this.btnOdgovor.Size = new System.Drawing.Size(323, 28);
            this.btnOdgovor.TabIndex = 29;
            this.btnOdgovor.Text = "Odgovori";
            this.btnOdgovor.UseVisualStyleBackColor = true;
            this.btnOdgovor.Click += new System.EventHandler(this.btnOdgovor_Click);
            // 
            // txtPoeni
            // 
            this.txtPoeni.Location = new System.Drawing.Point(101, 254);
            this.txtPoeni.Name = "txtPoeni";
            this.txtPoeni.Size = new System.Drawing.Size(399, 20);
            this.txtPoeni.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "Ukupno poena:";
            // 
            // txtPorukaSer
            // 
            this.txtPorukaSer.Location = new System.Drawing.Point(101, 228);
            this.txtPorukaSer.Name = "txtPorukaSer";
            this.txtPorukaSer.Size = new System.Drawing.Size(399, 20);
            this.txtPorukaSer.TabIndex = 26;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Poruka servera:";
            // 
            // txtOdgovor
            // 
            this.txtOdgovor.Location = new System.Drawing.Point(101, 156);
            this.txtOdgovor.Name = "txtOdgovor";
            this.txtOdgovor.Size = new System.Drawing.Size(399, 20);
            this.txtOdgovor.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Odgovor:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Kviz";
            // 
            // txtPitanje
            // 
            this.txtPitanje.Location = new System.Drawing.Point(101, 130);
            this.txtPitanje.Name = "txtPitanje";
            this.txtPitanje.Size = new System.Drawing.Size(399, 20);
            this.txtPitanje.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Pitanje:";
            // 
            // btnPrijava
            // 
            this.btnPrijava.Location = new System.Drawing.Point(177, 49);
            this.btnPrijava.Name = "btnPrijava";
            this.btnPrijava.Size = new System.Drawing.Size(323, 28);
            this.btnPrijava.TabIndex = 19;
            this.btnPrijava.Text = "Prijavi se";
            this.btnPrijava.UseVisualStyleBackColor = true;
            this.btnPrijava.Click += new System.EventHandler(this.btnPrijava_Click);
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(101, 12);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(399, 20);
            this.txtUser.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Username:";
            // 
            // FormKlijent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 295);
            this.Controls.Add(this.btnOdgovor);
            this.Controls.Add(this.txtPoeni);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPorukaSer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtOdgovor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPitanje);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPrijava);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.label1);
            this.Name = "FormKlijent";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormKlijent_FormClosed);
            this.Load += new System.EventHandler(this.FormKlijent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOdgovor;
        private System.Windows.Forms.TextBox txtPoeni;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPorukaSer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtOdgovor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPitanje;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPrijava;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label label1;
    }
}

