﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public delegate void Delegat(TransferKlasa transfer);
    public partial class FormKlijent : Form
    {
        Komunikacija k;
        public FormKlijent()
        {
            InitializeComponent();
        }

        private void FormKlijent_Load(object sender, EventArgs e)
        {
           
        }

        private void FormKlijent_FormClosed(object sender, FormClosedEventArgs e)
        {
            k.kraj();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          


        }


        void primiPOruku()
        {
            while (true)
            {
                TransferKlasa transfer = k.primiPoruku();
                Delegat d = new Klijent.Delegat(prikaziPOruku);
                Invoke(d, transfer);
            }
        }

        void prikaziPOruku(TransferKlasa transfer)
        {
            if (transfer.NovoPitanje) btnOdgovor.Enabled = true;
            else btnOdgovor.Enabled = false;
            txtPorukaSer.Text = transfer.Poruka;
            txtPitanje.Text = transfer.Pitanje;
            txtPoeni.Text = transfer.UkBrPoena.ToString();
        }

        private void btnPrijava_Click(object sender, EventArgs e)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Igrac = new Igrac();
            transfer.Igrac.Username = txtUser.Text;

            k = new Klijent.Komunikacija();
            transfer = k.poveziSe(transfer);
            if(transfer.Ulogovan)
            {
                this.Text = "Povezan!";
                MessageBox.Show(transfer.Poruka);

                ThreadStart ts = primiPOruku;
                new Thread(ts).Start();

                btnPrijava.Enabled = false;
                btnOdgovor.Enabled = true;
            }
            else MessageBox.Show(transfer.Poruka);

        }

        private void btnOdgovor_Click(object sender, EventArgs e)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Odgovor = txtOdgovor.Text;
            transfer.Operacija = Operacije.PosaljiPoruku;
            k.posaljiPoruku(transfer);
        }
    }
}
