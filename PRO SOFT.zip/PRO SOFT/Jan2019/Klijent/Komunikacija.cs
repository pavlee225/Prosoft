﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Klijent
{
    public class Komunikacija
    {
        TcpClient klijent;
        NetworkStream tok;
        BinaryFormatter formater;

        public TransferKlasa poveziSe(TransferKlasa transfer)
        {
            try
            {
                klijent = new TcpClient("localhost", 20000);
                tok = klijent.GetStream();
                formater = new BinaryFormatter();
                formater.Serialize(tok, transfer);

                return formater.Deserialize(tok) as TransferKlasa;

            }
            catch (Exception)
            {
                transfer.Ulogovan = false;
                transfer.Poruka = "Nesto ne valja!";
                return transfer;
            }
        }


        public void kraj()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.Kraj;
            formater.Serialize(tok, transfer);
        }

        internal void posaljiPoruku(TransferKlasa transfer)
        {            
            formater.Serialize(tok, transfer);
        }

        public TransferKlasa primiPoruku()
        {
            return formater.Deserialize(tok) as TransferKlasa;
        }
    }
}
