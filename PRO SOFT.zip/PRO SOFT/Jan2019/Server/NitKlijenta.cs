﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Server
{
    class NitKlijenta
    {
        private NetworkStream tok;
        BinaryFormatter formater;
        private Igrac i;

       

        public NitKlijenta(NetworkStream tok, Igrac i) 
        {
            this.i = i;
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradiKlijenta;
            new Thread(ts).Start();
        }

        void obradiKlijenta()
        {
            int a = 0;
            try
            {
                while (a != (int)Operacije.Kraj)
                {
                    TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;

                    switch (transfer.Operacija)
                    {
                        case Operacije.PosaljiPoruku:

                            if (Server.listaPitanja[Server.trenutnoPitanje].Odgovor == transfer.Odgovor)
                            {
                                i.BrTacnih++;
                                i.UkupnoPoena += Server.listaPitanja[Server.trenutnoPitanje].BrPoena;
                                Server.brPoenaIgraci += Server.listaPitanja[Server.trenutnoPitanje].BrPoena;
                            }
                            else
                            {
                                i.BrNetacnih++;
                                i.UkupnoPoena -= Server.listaPitanja[Server.trenutnoPitanje].BrPoena*0.2;
                                Server.brPoenaIgraci -= Server.listaPitanja[Server.trenutnoPitanje].BrPoena*0.2;
                            }
                            Server.brOdgovora++;
                            transfer.Poruka = i.Username+" je odgovorio, cekaj novo pitanje!";
                            transfer.UkBrPoena = Server.brPoenaIgraci;

                            foreach (NetworkStream tokkl in Server.listaTokova)
                            {
                                formater.Serialize(tokkl, transfer);
                            }

                          
                           
                            break;

                        case Operacije.Kraj:
                            a = 1;
                            Server.listaTokova.Remove(tok);
                            Server.listaIgraca.Remove(i);
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception)
            {
                Server.listaTokova.Remove(tok);
                Server.listaIgraca.Remove(i);


            }
        }
    }
}
