﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=ARSA-PC;Initial Catalog=Jan2019;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public List<Kviz> vratiSveKvizove()
        {
            List<Kviz> lista = new List<Kviz>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Kviz";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Kviz k = new Kviz();
                    k.Id = citac.GetInt32(0);
                    k.Naziv = citac.GetString(1);
                    //i.DatumVremePocetka = citac.GetDateTime(2);
                    //i.DatumVremeKraja = citac.GetDateTime(3);
                    //i.Pobednik = citac.GetString(4);
                    lista.Add(k);
                }
                citac.Close();

                return lista;

            }
            catch (Exception e)
            {
                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }

        }

        internal List<Pitanje> vratiPitanjaZaKviz(Kviz kviz)
        {
            List<Pitanje> lista = new List<Pitanje>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Pitanje where KvizID=" + kviz.Id + "";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Pitanje p = new Pitanje();
                    p.Id = citac.GetInt32(0);
                    p.PitanjeText = citac.GetString(1);
                    p.Odgovor = citac.GetString(2);
                    p.BrPoena = citac.GetInt32(3);
                    p.Kviz = kviz;
                    lista.Add(p);
                }
                citac.Close();
                return lista;


            }
            catch (Exception e)
            {
                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        internal void azurirajPocetak(Kviz kviz)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Update Kviz set DatumVremePocetka='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where KvizID=" + kviz.Id + "";

                komanda.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }
        internal void azurirajKraj(Kviz kviz)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Update Kviz set DatumVremeKraja='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', Pobednik='"+kviz.Pobednik+"' where KvizID=" + kviz.Id + "";

                komanda.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }
    }
}
