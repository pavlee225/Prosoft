﻿namespace Server
{
    partial class FormServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbKviz = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnPokreni = new System.Windows.Forms.Button();
            this.btnOdgovor = new System.Windows.Forms.Button();
            this.txtPoeni = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPorukaSer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtOdgovor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPitanje = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbKviz
            // 
            this.cmbKviz.FormattingEnabled = true;
            this.cmbKviz.Location = new System.Drawing.Point(75, 11);
            this.cmbKviz.Name = "cmbKviz";
            this.cmbKviz.Size = new System.Drawing.Size(422, 21);
            this.cmbKviz.TabIndex = 10;
            this.cmbKviz.SelectedIndexChanged += new System.EventHandler(this.cmbKviz_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Kviz:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 110);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(483, 216);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnPokreni
            // 
            this.btnPokreni.Location = new System.Drawing.Point(256, 54);
            this.btnPokreni.Name = "btnPokreni";
            this.btnPokreni.Size = new System.Drawing.Size(241, 32);
            this.btnPokreni.TabIndex = 7;
            this.btnPokreni.Text = "Pokreni kviz";
            this.btnPokreni.UseVisualStyleBackColor = true;
            this.btnPokreni.Click += new System.EventHandler(this.btnPokreni_Click);
            // 
            // btnOdgovor
            // 
            this.btnOdgovor.Enabled = false;
            this.btnOdgovor.Location = new System.Drawing.Point(174, 428);
            this.btnOdgovor.Name = "btnOdgovor";
            this.btnOdgovor.Size = new System.Drawing.Size(323, 28);
            this.btnOdgovor.TabIndex = 39;
            this.btnOdgovor.Text = "Odgovori";
            this.btnOdgovor.UseVisualStyleBackColor = true;
            this.btnOdgovor.Click += new System.EventHandler(this.btnOdgovor_Click);
            // 
            // txtPoeni
            // 
            this.txtPoeni.Location = new System.Drawing.Point(98, 500);
            this.txtPoeni.Name = "txtPoeni";
            this.txtPoeni.Size = new System.Drawing.Size(399, 20);
            this.txtPoeni.TabIndex = 38;
            this.txtPoeni.TextChanged += new System.EventHandler(this.txtPoeni_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 503);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 37;
            this.label5.Text = "Ukupno poena:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtPorukaSer
            // 
            this.txtPorukaSer.Location = new System.Drawing.Point(98, 474);
            this.txtPorukaSer.Name = "txtPorukaSer";
            this.txtPorukaSer.Size = new System.Drawing.Size(399, 20);
            this.txtPorukaSer.TabIndex = 36;
            this.txtPorukaSer.TextChanged += new System.EventHandler(this.txtPorukaSer_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 477);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 35;
            this.label6.Text = "Poruka servera:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtOdgovor
            // 
            this.txtOdgovor.Location = new System.Drawing.Point(98, 402);
            this.txtOdgovor.Name = "txtOdgovor";
            this.txtOdgovor.Size = new System.Drawing.Size(399, 20);
            this.txtOdgovor.TabIndex = 34;
            this.txtOdgovor.TextChanged += new System.EventHandler(this.txtOdgovor_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 405);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "Odgovor:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 347);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Kviz";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtPitanje
            // 
            this.txtPitanje.Location = new System.Drawing.Point(98, 376);
            this.txtPitanje.Name = "txtPitanje";
            this.txtPitanje.Size = new System.Drawing.Size(399, 20);
            this.txtPitanje.TabIndex = 31;
            this.txtPitanje.TextChanged += new System.EventHandler(this.txtPitanje_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 379);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 30;
            this.label2.Text = "Pitanje:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // FormServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 540);
            this.Controls.Add(this.btnOdgovor);
            this.Controls.Add(this.txtPoeni);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPorukaSer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtOdgovor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPitanje);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbKviz);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnPokreni);
            this.Name = "FormServer";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormServer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cmbKviz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnPokreni;
        private System.Windows.Forms.Button btnOdgovor;
        private System.Windows.Forms.TextBox txtPoeni;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPorukaSer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtOdgovor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPitanje;
        private System.Windows.Forms.Label label2;
    }
}

