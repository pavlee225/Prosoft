﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FormServer : Form
    {
        Server s;
        Timer t;
        public FormServer()
        {
            InitializeComponent();
        }

        private void FormServer_Load(object sender, EventArgs e)
        {
           
            

            cmbKviz.DataSource = Broker.dajSesiju().vratiSveKvizove();

            string[] lines = System.IO.File.ReadAllLines(@"..\\Podaci.txt");

            try
            {
                Server.port = Convert.ToInt32(lines[0]);
                Server.brIgraca = Convert.ToInt32(lines[1]);
            }
            catch (Exception)
            {

                MessageBox.Show("nisu ucitani podaci iz file!");
                return;
            }


           
        
        }

        private void btnPokreni_Click(object sender, EventArgs e)
        {
            s = new Server();
            if (s.pokreniServer())
            {
                this.Text = "Pokrenut!";

                Server.kviz = cmbKviz.SelectedItem as Kviz;
                Server.listaPitanja = Broker.dajSesiju().vratiPitanjaZaKviz(Server.kviz);
                Broker.dajSesiju().azurirajPocetak(Server.kviz);

                t = new Timer();
                t.Interval = 1000;
                t.Tick += osvezi;
                t.Start();

            }
        }

        bool prvi = true;
        private void osvezi(object sender, EventArgs e)
        {

            List<Igrac> lista = new List<Igrac>();
            foreach (Igrac i in Server.listaIgraca) lista.Add(i);
            dataGridView1.DataSource = lista;

            TransferKlasa transfer = new TransferKlasa();
            BinaryFormatter formater = new BinaryFormatter();

            if (Server.listaIgraca.Count == Server.brIgraca&&prvi )
            {
              
                prvi = false;
                transfer.Poruka = "Zapocni igru!";
                transfer.Pitanje = Server.listaPitanja[0].PitanjeText;
                transfer.NovoPitanje = true;
                foreach (NetworkStream tokKl in Server.listaTokova)
                {
                    formater.Serialize(tokKl, transfer);
                }

                txtPitanje.Text = transfer.Pitanje;
                MessageBox.Show(transfer.Poruka);
                btnOdgovor.Enabled = true;

            }

            if (Server.brOdgovora == 2)
            {
                Server.brOdgovora = 0;
                Server.trenutnoPitanje++;

               
                if (Server.trenutnoPitanje == Server.listaPitanja.Count-1)
                {
                    transfer.Kraj = true;
                    Server.kviz.DatumVremeKraja = DateTime.Now;
                    if (Server.brPoenaServer > Server.brPoenaIgraci)
                    {
                        transfer.Poruka = "Pobednik  je server!";
                        Server.kviz.Pobednik= "Server";
                    }

                    if (Server.brPoenaServer < Server.brPoenaIgraci)
                    {
                        transfer.Poruka = "Pobednici su igraci!";
                        Server.kviz.Pobednik = "Igraci";
                    }

                    if (Server.brPoenaServer == Server.brPoenaIgraci)
                    {
                        transfer.Poruka = "Nereseno!";
                        Server.kviz.Pobednik = "Nereseno";
                    }

                    Broker.dajSesiju().azurirajKraj(Server.kviz);

                    foreach (NetworkStream tokKl in Server.listaTokova)
                    {
                        formater.Serialize(tokKl, transfer);
                    }
                    t.Stop();
                    MessageBox.Show(transfer.Poruka);

                }
                else
                {
                    transfer.Poruka = "Novo pitanje!";
                    transfer.Pitanje = Server.listaPitanja[Server.trenutnoPitanje].PitanjeText;
                    transfer.NovoPitanje = true;
                    transfer.UkBrPoena = Server.brPoenaIgraci;
                    foreach (NetworkStream tokKl in Server.listaTokova)
                    {
                        formater.Serialize(tokKl, transfer);
                    }

                    txtPitanje.Text = transfer.Pitanje;
                    txtPorukaSer.Text = transfer.Poruka;
                }
            }

           

        }

        private void btnOdgovor_Click(object sender, EventArgs e)
        {
            if (Server.listaPitanja[Server.trenutnoPitanje].Odgovor == txtOdgovor.Text)
            {             
               
                Server.brPoenaServer += Server.listaPitanja[Server.trenutnoPitanje].BrPoena;
                txtPorukaSer.Text = "Tacan odgovor!";
            }
            else
            {
               
                Server.brPoenaServer -= Server.listaPitanja[Server.trenutnoPitanje].BrPoena * 0.2;
                txtPorukaSer.Text = "Netacan odgovor!";
            }
            Server.brOdgovora++;
            txtPoeni.Text = Server.brPoenaServer.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbKviz_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtPoeni_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtPorukaSer_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtOdgovor_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtPitanje_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
