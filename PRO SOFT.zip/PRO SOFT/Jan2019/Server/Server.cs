﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;


namespace Server
{
    public class Server
    {
        Socket soket;
        public static List<NetworkStream> listaTokova = new List<NetworkStream>();
        public static int brIgraca=0;
        public static int port = 0;
        public static Kviz kviz;
        public static List<Pitanje> listaPitanja;
        public static List<Igrac> listaIgraca = new List<Igrac>();
        public static double brPoenaServer = 0;
        public static double brPoenaIgraci = 0;
        public static int trenutnoPitanje = 0;
        public static int brOdgovora = 0;


        public bool pokreniServer()
        {
            try
            {
                soket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint ep = new IPEndPoint(IPAddress.Any, port);
                soket.Bind(ep);

                ThreadStart ts = osluskuj;
                new Thread(ts).Start();

                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool zaustaviServer()
        {
            try
            {
                soket.Close();
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        void osluskuj()
        {
            try
            {
                while (true)
                {
                    soket.Listen(8);
                    Socket klijent = soket.Accept();
                    NetworkStream tok = new NetworkStream(klijent);
                    BinaryFormatter formater = new BinaryFormatter();

                    TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;

                    transfer.Ulogovan = true;
                    Igrac i = transfer.Igrac;
                    
                    if (listaIgraca.Contains(i))
                    {
                        transfer.Poruka = "Vec si se ulogovao!";
                        transfer.Ulogovan = false;
                    }

                    if (transfer.Ulogovan&& listaIgraca.Count==brIgraca)
                    {
                        transfer.Poruka = "Nema vise mesta!";
                        transfer.Ulogovan = false;
                    }

                    if (transfer.Ulogovan)
                    {
                        new NitKlijenta(tok,i);
                        listaTokova.Add(tok);
                        listaIgraca.Add(i);
                        transfer.Poruka = "Cekaj da pocne igra!";
                    }

                    formater.Serialize(tok, transfer);






                  
                }
            }
            catch (Exception)
            {

               
            }
        }

    }
}
