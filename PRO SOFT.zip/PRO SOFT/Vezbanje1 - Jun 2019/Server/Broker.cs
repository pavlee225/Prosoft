﻿using Domen;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Jun2019;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public List<Stanica> vratiSveStanice()
        {
            List<Stanica> lista = new List<Stanica>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Stanica";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Stanica s = new Stanica();
                    s.Id = citac.GetInt32(0);
                    s.Naziv = citac.GetString(1);
                    lista.Add(s);
                }
                citac.Close();
                
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiIDLinije()
        {
            try
            {

                komanda.CommandText = "Select max(LinijaID) from Linija";
                object o = komanda.ExecuteScalar();
                if (o == DBNull.Value) return 1;
                else return Convert.ToInt32(o);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public string sacuvajLiniju(Linija l)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);
                komanda.CommandText = "Insert into Linija (NazivLinije, PocetnaStanica, KrajnjaStanica) values ('"+l.Naziv+"',"+l.PocetnaStanica.Id+","+l.KrajnjaStanica.Id+")";
                komanda.ExecuteNonQuery();
                l.Id = vratiIDLinije();
                foreach (LinijaStanica ls in l.Medjustanice)
                {
                    komanda.CommandText = "Insert into LinijaStanica values(" + l.Id + "," +ls.Stanica.Id +")";
                    komanda.ExecuteNonQuery();
                }

                //validacija
                

                transakcija.Commit();
                return "Sacuvano!";
            }
            catch (Exception ex)
            {
                transakcija.Rollback();
                System.Windows.Forms.MessageBox.Show(ex.Message);
                return "Nije sacuvano!";
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
