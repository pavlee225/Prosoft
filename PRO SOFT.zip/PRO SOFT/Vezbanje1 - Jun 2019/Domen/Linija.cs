﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Linija
    {
        public Linija()
        {
            Medjustanice = new BindingList<LinijaStanica>();
        }
        public override string ToString()
        {
            return naziv;
        }

        int id;
        string naziv;
        Stanica pocetnaStanica;
        Stanica krajnjaStanica;
        BindingList<LinijaStanica> medjustanice;

        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public Stanica PocetnaStanica { get => pocetnaStanica; set => pocetnaStanica = value; }
        public Stanica KrajnjaStanica { get => krajnjaStanica; set => krajnjaStanica = value; }
        public BindingList<LinijaStanica> Medjustanice { get => medjustanice; set => medjustanice = value; }
    }
}
