﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        Linija linija;

        public FormaKlijent()
        {
            InitializeComponent();
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            

            linija = new Linija();
            dataGridView1.DataSource = linija.Medjustanice;

            //popunjavanje combobox-a
            cmbPocetna.DataSource = k.vratiSveStanice();
            cmbKrajnja.DataSource = k.vratiSveStanice();
            cmbMedjustanice.DataSource = k.vratiSveStanice();

            //popunjavanje datagrid-a
            //linija = new Linija();
            //dataGridView1.DataSource = linija.Medjustanice;
            //lista = new BindingList<LinijaStanica>();
            //dataGridView1.DataSource = lista;

        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            LinijaStanica ls = new LinijaStanica();
            ls.Linija = linija;
            ls.Stanica = cmbMedjustanice.SelectedItem as Stanica;

            try
            {
                linija.PocetnaStanica = new Stanica();
                linija.PocetnaStanica = cmbPocetna.SelectedItem as Stanica;
                if (ls.Stanica.Id == linija.PocetnaStanica.Id)
                {
                    MessageBox.Show("Ne mogu da budu ista pocetna i medjustanica!");
                    return;
                }
                linija.KrajnjaStanica = new Stanica();
                linija.KrajnjaStanica = cmbKrajnja.SelectedItem as Stanica;
                if (ls.Stanica.Id == linija.KrajnjaStanica.Id)
                {
                    MessageBox.Show("Ne mogu da budu ista krajnja i medjustanica!");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            linija.Medjustanice.Add(ls);
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            Linija lin = new Linija();

            lin.Naziv = txtNaziv.Text;
            if(lin.Naziv == "")
            {
                MessageBox.Show("Niste uneli naziv linije!");
                return;
            }

            lin.PocetnaStanica = new Stanica();
            try
            {
                lin.PocetnaStanica = cmbPocetna.SelectedItem as Stanica;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali pocetnu stanicu!");
                return;
            }
            lin.KrajnjaStanica = new Stanica();
            try
            {
                lin.KrajnjaStanica = cmbKrajnja.SelectedItem as Stanica;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali kranju stanicu!");
                return;
            }

            if (lin.PocetnaStanica.Id == lin.KrajnjaStanica.Id)
            {
                MessageBox.Show("Moraju biti razlicite pocetna i krajnja stanica!");
                return;
            }

            lin.Medjustanice = linija.Medjustanice;
            
            if(lin.Medjustanice.Count < 1)
            {
                MessageBox.Show("Linija mora imati barem jednu medjustanicu!");
                return;
            }

            string poruka = k.sacuvajLiniju(lin);
            MessageBox.Show(poruka);
        }


    }
}
