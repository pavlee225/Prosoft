﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteka;

namespace Sesija
{
    public class Broker
    {
        SqlConnection konekcija;
        SqlCommand komanda;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Baza1Kol2018G2;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        //metode
        public Korisnik login(Korisnik k)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Korisnik where KorisnickoIme='" + k.Username + "' and KorisnickaSifra='" + k.Passowrd + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                if(citac.Read())
                {
                    k.Id = citac.GetInt32(0);
                    k.Ime = citac.GetString(1);
                    k.Prezime = citac.GetString(2);

                    citac.Close();
                    return k;
                }
                citac.Close();
                return null;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Student> vratiSveStudente()
        {
            List<Student> lista = new List<Student>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Student1";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Student s = new Student();
                    s.BrInd = citac.GetInt32(0);
                    s.Ime = citac.GetString(1);
                    s.Prezime = citac.GetString(2);

                    lista.Add(s);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Predmet> vratiSvePredmete()
        {
            List<Predmet> lista = new List<Predmet>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Predmet";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Predmet p = new Predmet();
                    p.PredmetID= citac.GetInt32(0);
                    p.Naziv= citac.GetString(1);

                    lista.Add(p);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<PredajePredmet> vratiSveProfesoreZaPredmet(Predmet p)
        {
            List<PredajePredmet> lista = new List<PredajePredmet>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from PredajePredmet pp inner join Profesor p on pp.profesorID=p.ID where pp.predmetID="+p.PredmetID;
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    PredajePredmet pp = new PredajePredmet();
                    pp.Predmet = p;
                    pp.Profesor = new Profesor();
                    pp.Profesor.Id = citac.GetInt32(2);
                    pp.Profesor.Ime = citac.GetString(3);
                    pp.Profesor.Prezime = citac.GetString(4);

                    lista.Add(pp);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiSifru()
        {
            try
            {
                komanda.CommandText = "Select max(ID) from Prijava";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {
                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void sacuvajPrijave(List<Prijava> lista)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                foreach(Prijava p in lista)
                {
                    p.Id = vratiSifru();
                    komanda.CommandText = "Insert into Prijava values("+p.Id+",'"+p.Datum.ToShortDateString()+"',"+p.Ocena+",'"+p.Rok.Naziv+"',"+p.Student.BrInd+","+p.Korisnik.Id+","+p.PredajePredmet.Predmet.PredmetID+","+p.PredajePredmet.Profesor.Id+")";
                    komanda.ExecuteNonQuery();
                    transakcija.Commit();
                }
            }
            catch (Exception)
            {
                transakcija.Rollback();
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public bool proveriOcenuZaPredmet(Prijava p)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Prijava where Ocena>5 and PredmetID ="+p.PredajePredmet.Predmet.PredmetID+"and StudentID="+p.Student.BrInd;
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    citac.Close();
                    return true;
                }
                citac.Close();
                return false;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
