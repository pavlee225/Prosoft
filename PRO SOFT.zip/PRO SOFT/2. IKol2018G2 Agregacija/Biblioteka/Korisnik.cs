﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class Korisnik
    {
        public override string ToString()
        {
            return ime+" "+prezime;
        }

        int id;
        string ime;
        string prezime;
        string username;
        string passowrd;

        public int Id { get => id; set => id = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string Username { get => username; set => username = value; }
        public string Passowrd { get => passowrd; set => passowrd = value; }
    }
}
