﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class Predmet
    {
        public override string ToString()
        {
            return naziv;
        }

        int predmetID;
        string naziv;

        public int PredmetID { get => predmetID; set => predmetID = value; }
        public string Naziv { get => naziv; set => naziv = value; }
    }
}
