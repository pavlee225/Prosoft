﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class IspitniRok
    {
        public override string ToString()
        {
            return naziv;
        }

        string naziv;
        DateTime datumOD;
        DateTime datumDO;

        public string Naziv { get => naziv; set => naziv = value; }
        public DateTime DatumOD { get => datumOD; set => datumOD = value; }
        public DateTime DatumDO { get => datumDO; set => datumDO = value; }
    }
}
