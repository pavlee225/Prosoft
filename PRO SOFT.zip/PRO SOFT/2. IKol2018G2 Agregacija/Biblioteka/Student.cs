﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class Student
    {
        public override string ToString()
        {
            return ime+" "+prezime;
        }

        int brInd;
        string ime;
        string prezime;

        public int BrInd { get => brInd; set => brInd = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
    }
}
