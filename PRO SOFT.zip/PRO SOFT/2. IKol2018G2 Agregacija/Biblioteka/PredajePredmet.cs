﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class PredajePredmet
    {
        public override string ToString()
        {
            return profesor.ToString();
        }

        Predmet predmet;
        Profesor profesor;

        public Predmet Predmet { get => predmet; set => predmet = value; }
        public Profesor Profesor { get => profesor; set => profesor = value; }
    }
}
