﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class Prijava
    {
        int id;
        DateTime datum;
        int ocena;
        IspitniRok rok;
        Student student;
        Korisnik korisnik;
        PredajePredmet predajePredmet;

        public int Id { get => id; set => id = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        public int Ocena { get => ocena; set => ocena = value; }
        public IspitniRok Rok { get => rok; set => rok = value; }
        public Student Student { get => student; set => student = value; }
        public Korisnik Korisnik { get => korisnik; set => korisnik = value; }
        public PredajePredmet PredajePredmet { get => predajePredmet; set => predajePredmet = value; }
        
    }
}
