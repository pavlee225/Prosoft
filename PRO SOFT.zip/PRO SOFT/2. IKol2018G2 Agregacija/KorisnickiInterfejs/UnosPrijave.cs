﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteka;
using Sesija;

namespace KorisnickiInterfejs
{
    public partial class UnosPrijave : Form
    {
        private Korisnik k;
        List<IspitniRok> listaRokova;
        BindingList<Prijava> listaPrijava;

        void popuniRokove()
        {
            listaRokova = new List<IspitniRok>();
            listaRokova.Add(new IspitniRok() { Naziv = "Jun2019", DatumOD = DateTime.Now.AddMonths(3), DatumDO = DateTime.Now.AddMonths(4) });
            listaRokova.Add(new IspitniRok() { Naziv = "Jul2019", DatumOD = DateTime.Now.AddMonths(4), DatumDO = DateTime.Now.AddMonths(5) });
            listaRokova.Add(new IspitniRok() { Naziv = "Sept2019", DatumOD = DateTime.Now.AddMonths(6), DatumDO = DateTime.Now.AddMonths(7) });

        }

        public UnosPrijave()
        {
            InitializeComponent();
        }

        public UnosPrijave(Korisnik k)
        {
            InitializeComponent();
            this.k = k;
        }

        private void UnosPrijave_Load(object sender, EventArgs e)
        {
            popuniRokove();
            cmbIspitniRok.DataSource = listaRokova;

            cmbStudent.DataSource = Broker.dajSesiju().vratiSveStudente();
            cmbPredmet.DataSource = Broker.dajSesiju().vratiSvePredmete();
        }

        private void cmbIspitniRok_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                IspitniRok ir = cmbIspitniRok.SelectedItem as IspitniRok;
                txtDatumOd.Text = ir.DatumOD.ToShortDateString();
                txtDatumDo.Text = ir.DatumDO.ToShortDateString();

                listaPrijava = new BindingList<Prijava>();
                dataGridViewDonji.DataSource = listaPrijava;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void cmbPredmet_SelectedIndexChanged(object sender, EventArgs e)
        {
            Predmet p = cmbPredmet.SelectedItem as Predmet;
            cmbProfesor.DataSource = Broker.dajSesiju().vratiSveProfesoreZaPredmet(p);
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            Prijava p = new Prijava();
            p.Korisnik = k;
            try
            {
                p.Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije validan datum!");
                return;
            }

            p.Rok = cmbIspitniRok.SelectedItem as IspitniRok;
            if(p.Rok == null)
            {
                MessageBox.Show("Niste odabrali rok!");
                return;
            }
            //datum iz okvira
            if(p.Datum<p.Rok.DatumOD || p.Datum > p.Rok.DatumDO)
            {
                MessageBox.Show("Datum nije u roku!");
                return;
            }

            p.PredajePredmet = cmbProfesor.SelectedItem as PredajePredmet;
            if(p.PredajePredmet == null)
            {
                MessageBox.Show("Niste odabrali profesora i predmet!");
                return;
            }

            p.Student = cmbStudent.SelectedItem as Student;
            if(p.Student == null)
            {
                MessageBox.Show("Fali student");
                return;
            }

            try
            {
                p.Ocena = Convert.ToInt32(txtOcena.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije validna ocena!");
                return;
            }
            if(p.Ocena<5 || p.Ocena > 10)
            {
                MessageBox.Show("Ocena mora biti od 5-10");
                return;
            }

            //jedan predmet jedna ocena jedan student
            foreach(Prijava pr in listaPrijava)
            {
                if(p.Student.BrInd == pr.Student.BrInd && pr.PredajePredmet.Predmet.PredmetID == pr.PredajePredmet.Predmet.PredmetID)
                {
                    MessageBox.Show("Ne moze ponovo isti student za isti predmet!");
                }
            }

            //proveri da li postoji pozitivna ocena
            if (p.Ocena > 5 && Broker.dajSesiju().proveriOcenuZaPredmet(p))
            {
                MessageBox.Show("Ne mogu dve pozitivne ocene!");
                return;
            }

            listaPrijava.Add(p);
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                Prijava p = dataGridViewDonji.CurrentRow.DataBoundItem as Prijava;
                listaPrijava.Remove(p);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali!");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                Broker.dajSesiju().sacuvajPrijave(new List<Prijava>(listaPrijava));
                MessageBox.Show("Sacuvano!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nije sacuvano!\nGreska:"+ex.Message);
            }
        }
    }
}
