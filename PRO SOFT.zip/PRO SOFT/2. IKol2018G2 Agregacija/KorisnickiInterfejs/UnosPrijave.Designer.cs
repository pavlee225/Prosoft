﻿namespace KorisnickiInterfejs
{
    partial class UnosPrijave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbIspitniRok = new System.Windows.Forms.ComboBox();
            this.cmbStudent = new System.Windows.Forms.ComboBox();
            this.cmbProfesor = new System.Windows.Forms.ComboBox();
            this.cmbPredmet = new System.Windows.Forms.ComboBox();
            this.txtDatumDo = new System.Windows.Forms.TextBox();
            this.txtOcena = new System.Windows.Forms.TextBox();
            this.txtDatum = new System.Windows.Forms.TextBox();
            this.txtDatumOd = new System.Windows.Forms.TextBox();
            this.dataGridViewGornji = new System.Windows.Forms.DataGridView();
            this.dataGridViewDonji = new System.Windows.Forms.DataGridView();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnObrisi = new System.Windows.Forms.Button();
            this.btnSacuvaj = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGornji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDonji)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ispitni rok:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Student:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ocena:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Profesor:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Datum:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Predmet:";
            // 
            // cmbIspitniRok
            // 
            this.cmbIspitniRok.FormattingEnabled = true;
            this.cmbIspitniRok.Location = new System.Drawing.Point(73, 6);
            this.cmbIspitniRok.Name = "cmbIspitniRok";
            this.cmbIspitniRok.Size = new System.Drawing.Size(121, 21);
            this.cmbIspitniRok.TabIndex = 6;
            this.cmbIspitniRok.SelectedIndexChanged += new System.EventHandler(this.cmbIspitniRok_SelectedIndexChanged);
            // 
            // cmbStudent
            // 
            this.cmbStudent.FormattingEnabled = true;
            this.cmbStudent.Location = new System.Drawing.Point(73, 145);
            this.cmbStudent.Name = "cmbStudent";
            this.cmbStudent.Size = new System.Drawing.Size(121, 21);
            this.cmbStudent.TabIndex = 7;
            // 
            // cmbProfesor
            // 
            this.cmbProfesor.FormattingEnabled = true;
            this.cmbProfesor.Location = new System.Drawing.Point(73, 86);
            this.cmbProfesor.Name = "cmbProfesor";
            this.cmbProfesor.Size = new System.Drawing.Size(121, 21);
            this.cmbProfesor.TabIndex = 8;
            // 
            // cmbPredmet
            // 
            this.cmbPredmet.FormattingEnabled = true;
            this.cmbPredmet.Location = new System.Drawing.Point(73, 33);
            this.cmbPredmet.Name = "cmbPredmet";
            this.cmbPredmet.Size = new System.Drawing.Size(121, 21);
            this.cmbPredmet.TabIndex = 9;
            this.cmbPredmet.SelectedIndexChanged += new System.EventHandler(this.cmbPredmet_SelectedIndexChanged);
            // 
            // txtDatumDo
            // 
            this.txtDatumDo.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDatumDo.Location = new System.Drawing.Point(299, 6);
            this.txtDatumDo.Name = "txtDatumDo";
            this.txtDatumDo.Size = new System.Drawing.Size(78, 20);
            this.txtDatumDo.TabIndex = 10;
            // 
            // txtOcena
            // 
            this.txtOcena.Location = new System.Drawing.Point(73, 115);
            this.txtOcena.Name = "txtOcena";
            this.txtOcena.Size = new System.Drawing.Size(121, 20);
            this.txtOcena.TabIndex = 11;
            // 
            // txtDatum
            // 
            this.txtDatum.Location = new System.Drawing.Point(73, 63);
            this.txtDatum.Name = "txtDatum";
            this.txtDatum.Size = new System.Drawing.Size(121, 20);
            this.txtDatum.TabIndex = 12;
            // 
            // txtDatumOd
            // 
            this.txtDatumOd.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDatumOd.Location = new System.Drawing.Point(217, 6);
            this.txtDatumOd.Name = "txtDatumOd";
            this.txtDatumOd.Size = new System.Drawing.Size(76, 20);
            this.txtDatumOd.TabIndex = 13;
            // 
            // dataGridViewGornji
            // 
            this.dataGridViewGornji.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGornji.Location = new System.Drawing.Point(217, 33);
            this.dataGridViewGornji.Name = "dataGridViewGornji";
            this.dataGridViewGornji.Size = new System.Drawing.Size(290, 133);
            this.dataGridViewGornji.TabIndex = 14;
            // 
            // dataGridViewDonji
            // 
            this.dataGridViewDonji.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDonji.Location = new System.Drawing.Point(15, 198);
            this.dataGridViewDonji.Name = "dataGridViewDonji";
            this.dataGridViewDonji.Size = new System.Drawing.Size(492, 164);
            this.dataGridViewDonji.TabIndex = 15;
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(15, 172);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(140, 23);
            this.btnDodaj.TabIndex = 16;
            this.btnDodaj.Text = "Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnObrisi
            // 
            this.btnObrisi.Location = new System.Drawing.Point(367, 169);
            this.btnObrisi.Name = "btnObrisi";
            this.btnObrisi.Size = new System.Drawing.Size(140, 23);
            this.btnObrisi.TabIndex = 17;
            this.btnObrisi.Text = "Obrisi";
            this.btnObrisi.UseVisualStyleBackColor = true;
            this.btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);
            // 
            // btnSacuvaj
            // 
            this.btnSacuvaj.Location = new System.Drawing.Point(15, 368);
            this.btnSacuvaj.Name = "btnSacuvaj";
            this.btnSacuvaj.Size = new System.Drawing.Size(492, 35);
            this.btnSacuvaj.TabIndex = 18;
            this.btnSacuvaj.Text = "Sacuvaj";
            this.btnSacuvaj.UseVisualStyleBackColor = true;
            this.btnSacuvaj.Click += new System.EventHandler(this.btnSacuvaj_Click);
            // 
            // UnosPrijave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 429);
            this.Controls.Add(this.btnSacuvaj);
            this.Controls.Add(this.btnObrisi);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.dataGridViewDonji);
            this.Controls.Add(this.dataGridViewGornji);
            this.Controls.Add(this.txtDatumOd);
            this.Controls.Add(this.txtDatum);
            this.Controls.Add(this.txtOcena);
            this.Controls.Add(this.txtDatumDo);
            this.Controls.Add(this.cmbPredmet);
            this.Controls.Add(this.cmbProfesor);
            this.Controls.Add(this.cmbStudent);
            this.Controls.Add(this.cmbIspitniRok);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UnosPrijave";
            this.Text = "UnosPrijave";
            this.Load += new System.EventHandler(this.UnosPrijave_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGornji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDonji)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbIspitniRok;
        private System.Windows.Forms.ComboBox cmbStudent;
        private System.Windows.Forms.ComboBox cmbProfesor;
        private System.Windows.Forms.ComboBox cmbPredmet;
        private System.Windows.Forms.TextBox txtDatumDo;
        private System.Windows.Forms.TextBox txtOcena;
        private System.Windows.Forms.TextBox txtDatum;
        private System.Windows.Forms.TextBox txtDatumOd;
        private System.Windows.Forms.DataGridView dataGridViewGornji;
        private System.Windows.Forms.DataGridView dataGridViewDonji;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnObrisi;
        private System.Windows.Forms.Button btnSacuvaj;
    }
}