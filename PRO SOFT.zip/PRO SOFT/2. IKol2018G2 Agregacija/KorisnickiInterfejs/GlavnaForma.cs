﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteka;

namespace KorisnickiInterfejs
{
    public partial class GlavnaForma : Form
    {
        private Korisnik k;

        public GlavnaForma()
        {
            InitializeComponent();
        }

        public GlavnaForma(Korisnik pi)
        {
            InitializeComponent();
            this.k = pi;
            this.Text = k.ToString();
        }

        private void iIGrupaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new UnosPrijave(k).ShowDialog();
        }
    }
}
