﻿using Biblioteka;
using Sesija;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        int br = 0;
        private void btnPrijaviSe_Click(object sender, EventArgs e)
        {
            Korisnik k = new Korisnik();
            k.Username = txtUser.Text;
            k.Passowrd = txtPass.Text;

            if (br == 3)
            {
                MessageBox.Show("Nemate vise pokusaja!");
                btnPrijaviSe.Enabled = false;
                return;
            }

            try
            {
                k = Broker.dajSesiju().login(k);
                br++;
                if (k == null)
                {
                    MessageBox.Show("Nema Vas!\nOstalo Vam je jos "+(3-br)+" pokusaja.");
                }
                else
                {
                    new GlavnaForma(k).ShowDialog();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
