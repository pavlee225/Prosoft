﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public delegate void Delegat(TransferKlasa transfer);
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        public FormaKlijent()
        {
            InitializeComponent();
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
                ThreadStart ts = primiPoruku;
                new Thread(ts).Start();
            }
        }

        private void txtSend_Click(object sender, EventArgs e)
        {
            Korisnik kor = new Korisnik();
            kor.Username = txtUsername.Text;
            if(kor.Username == "")
            {
                MessageBox.Show("Niste uneli username!");
                txtUsername.Focus();
                return;
            }
            txtUsername.ReadOnly = true;

            TransferKlasa transfer = new TransferKlasa();
            transfer.korisnik = kor;
            transfer.Poruka = txtPoruka.Text;

            txtChat.Text += "\r\n" + DateTime.Now.ToString("HH:mm") + "\t" +transfer.Poruka;

            k.posaljiPoruku(transfer);
        }

        void primiPoruku()
        {
            while (true)
            {
                TransferKlasa transfer = k.primiPoruku();
                Delegat d = new Delegat(prikaziPoruku);
                Invoke(d, transfer);
            }
        }

        void prikaziPoruku(TransferKlasa transfer)
        {
            txtChat.Text += "\r\n" + DateTime.Now.ToString("HH:mm") + "\t" + transfer.Odgovor;
        }
    }
}
