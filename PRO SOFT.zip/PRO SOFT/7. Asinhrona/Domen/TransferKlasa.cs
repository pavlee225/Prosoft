﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Operacije { Kraj=1, SlanjePoruke}

    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public string Poruka;
        public Korisnik korisnik;
        public string Odgovor;
    }
}
