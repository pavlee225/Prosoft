﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace ServerKonzola
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction tramsakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Predrok2018;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        private string filter;

        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public PoreskiInspektor login(PoreskiInspektor p)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from PoreskiInspektor where KorisnickoIme='" + p.KorisnickoIme + "'and Lozinka='" + p.Lozinka + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    p.InspektorID = citac.GetInt32(0);
                    p.ImePrezime = citac.GetString(1);
                    citac.Close();
                    return p;
                }
                citac.Close();
                return null;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        internal List<KlasaZaServer> vratiSveZaServer(string kriterijum)
        {
            List<KlasaZaServer> lista = new List<KlasaZaServer>();
            try
            {
                konekcija.Open();
                if(filter == "fizicko" || filter == "")
                {
                    komanda.CommandText = "Select f.ObveznikID, f.ImePrezime, p.Godina, sum(sp.Vrednost*(v.ProcenatPoreza/100)) as dug from FizickoLice f inner join PoreskaPrijava p on f.ObveznikID=p.ObveznikID inner join StavkaPoreskePrijave sp on p.ObveznikID=sp.PrijavaID inner join VrstaPoreza v on sp.VrstaID=v.VrstaID where Godina=" + DateTime.Now.Year + " group by f.ObveznikID, f.ImePrezime, p.Godina order by dug desc";
                    SqlDataReader citac = komanda.ExecuteReader();
                    while (citac.Read())
                    {
                        KlasaZaServer k = new KlasaZaServer();
                        k.Id = citac.GetInt32(0);
                        k.Naziv = citac.GetString(1);
                        k.Godina = citac.GetInt32(2);
                        try
                        {
                            k.Dug = Convert.ToDouble(citac.GetValue(3));
                        }
                        catch (Exception)
                        {
                            
                        }
                        k.Tip = "Fizicko";
                        lista.Add(k);
                    }
                    citac.Close();
                }
                if(filter == "pravno"|| filter == "")
                {
                    komanda.CommandText = "Select f.ObveznikID, f.ImePrezime, p.Godina, sum(sp.Vrednost*(v.ProcenatPoreza/100)) as dug from PravnoLice f inner join PoreskaPrijava p on f.ObveznikID=p.ObveznikID inner join StavkaPoreskePrijave sp on p.ObveznikID=sp.PrijavaID inner join VrstaPoreza v on sp.VrstaID=v.VrstaID where Godina=" + DateTime.Now.Year + " group by f.ObveznikID, f.ImePrezime, p.Godina order by dug desc";
                    SqlDataReader citac = komanda.ExecuteReader();
                    while (citac.Read())
                    {
                        KlasaZaServer k = new KlasaZaServer();
                        k.Id = citac.GetInt32(0);
                        k.Naziv = citac.GetString(1);
                        k.Godina = citac.GetInt32(2);
                        try
                        {
                            k.Dug = Convert.ToDouble(citac.GetValue(3));
                        }
                        catch (Exception)
                        {
                            
                        }
                        k.Tip = "Pravno";
                        lista.Add(k);
                    }
                }
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Vrsta> vratiSveVrste()
        {
            List<Vrsta> lista = new List<Vrsta>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from VrstaPoreza";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Vrsta v = new Vrsta();
                    v.Id = citac.GetInt32(0);
                    v.Naziv = citac.GetString(1);
                    v.Procenat = Convert.ToDouble(2);
                    lista.Add(v);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<PoreskiObveznik> vratiSveObveznike()
        {
            List<PoreskiObveznik> lista = new List<PoreskiObveznik>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from FizickoLice";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    FizickoLice f = new FizickoLice();
                    f.Id = citac.GetInt32(0);
                    f.Jmbg = citac.GetString(1);
                    f.ImePrezime = citac.GetString(2);
                    lista.Add(f);
                }
                citac.Close();

                komanda.CommandText = "Select * from PravnoLice";
                citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    PravnoLice p = new PravnoLice();
                    p.Id = citac.GetInt32(0);
                    p.Pib = citac.GetString(1);
                    p.MatBr = citac.GetString(2);
                    p.Naziv = citac.GetString(3);
                    lista.Add(p);
                }
                citac.Close();

                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiSifruPrijave()
        {
            try
            {
                komanda.CommandText = "Select max(PrijavaID) from PoreskaPrijava";
                try
                {
                    return Convert.ToInt32(komanda.ExecuteScalar()) + 1;
                }
                catch (Exception)
                {
                    return 1; 
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool sacuvajPrijavu(PoreskaPrijava p)
        {
            try
            {
                konekcija.Open();
                tramsakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, tramsakcija);
                p.Id = vratiSifruPrijave();
                komanda.CommandText = "Insert into PoreskaPrijava values(" + p.Id + "," + p.Godina + "," + p.Obveznik.Id + "," + p.Inspektor.InspektorID + ")";
                komanda.ExecuteNonQuery();

                foreach(StavkaPrijave sp in p.ListaStavki)
                {
                    komanda.CommandText = "Insert into StavkaPrijave values(" + p.Id + "," + sp.RBr + ",'" + sp.Datum.ToString("yyyy-MM-dd") + "'," + sp.Vrednost + ",'" + sp.Napomena + "'," + sp.Vrsta.Id + ")";
                    komanda.ExecuteNonQuery();
                }
                tramsakcija.Commit();
                return true;
            }
            catch (Exception)
            {
                tramsakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
