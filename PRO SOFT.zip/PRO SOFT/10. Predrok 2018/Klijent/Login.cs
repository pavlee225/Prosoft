﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnPrijaviSe_Click(object sender, EventArgs e)
        {
            Komunikacija k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                PoreskiInspektor p = new PoreskiInspektor();
                p.KorisnickoIme = txtUsername.Text;
                p.Lozinka = txtPass.Text;

                p = k.login(p);

                if (p == null)
                {
                    MessageBox.Show("Neuspelo logovanje!");
                }
                else
                {
                    new FormaKlijent(p, k).ShowDialog();
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
