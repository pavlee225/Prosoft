﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class UnosStavke : Form
    {
        private PoreskiInspektor p;
        private Komunikacija k;
        private PoreskaPrijava prijava;
        private Vrsta v;

        public UnosStavke()
        {
            
        }

        public UnosStavke(PoreskiInspektor p, Komunikacija k, PoreskaPrijava prijava, Vrsta v)
        {
            InitializeComponent();
            this.p = p;
            this.k = k;
            this.prijava = prijava;
            this.v = v;
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            StavkaPrijave sp = new StavkaPrijave();
            sp.RBr = prijava.ListaStavki.Count + 1;
            sp.Vrsta = v;

            try
            {
                sp.Datum = Convert.ToDateTime(txtDatum.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste dobro uneli datum!");
                return;
            }

            sp.Napomena = txtNapomena.Text;
            if(sp.Napomena == "")
            {
                MessageBox.Show("Fali napomena!");
                return;
            }

            try
            {
                sp.Vrednost = Convert.ToDouble(txtVrednost.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Losa vrednost!");
                return;
            }
            if(sp.Vrednost <= 0)
            {
                MessageBox.Show("Ne valja vrednos!");
                return;
            }

            prijava.ListaStavki.Add(sp);

            this.Close();
        }
    }
}
