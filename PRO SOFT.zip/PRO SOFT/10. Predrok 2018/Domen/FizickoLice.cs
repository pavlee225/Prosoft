﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class FizickoLice :PoreskiObveznik
    {
        public override string ToString()
        {
            return imePrezime;
        }

        string imePrezime;
        string jmbg;

        public string ImePrezime { get => imePrezime; set => imePrezime = value; }
        public string Jmbg { get => jmbg; set => jmbg = value; }
    }
}
