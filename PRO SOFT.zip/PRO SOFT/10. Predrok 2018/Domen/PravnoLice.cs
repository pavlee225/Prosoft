﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class PravnoLice :PoreskiObveznik
    {
        public override string ToString()
        {
            return naziv;
        }

        string naziv;
        string pib;
        string matBr;

        public string Naziv { get => naziv; set => naziv = value; }
        public string Pib { get => pib; set => pib = value; }
        public string MatBr { get => matBr; set => matBr = value; }
    }
}
