﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class PoreskaPrijava
    {
        public PoreskaPrijava()
        {
            listaStavki = new BindingList<StavkaPrijave>();
        }

        int id;
        int godina;
        PoreskiObveznik obveznik;
        PoreskiInspektor inspektor;
        BindingList<StavkaPrijave> listaStavki;

        public int Id { get => id; set => id = value; }
        public int Godina { get => godina; set => godina = value; }
        public PoreskiObveznik Obveznik { get => obveznik; set => obveznik = value; }
        public PoreskiInspektor Inspektor { get => inspektor; set => inspektor = value; }
        public BindingList<StavkaPrijave> ListaStavki { get => listaStavki; set => listaStavki = value; }
    }
}
