﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class StavkaPrijave
    {
        int rBr;
        DateTime datum;
        double vrednost;
        string napomena;
        Vrsta vrsta;

        public int RBr { get => rBr; set => rBr = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        public double Vrednost { get => vrednost; set => vrednost = value; }
        public string Napomena { get => napomena; set => napomena = value; }
        public Vrsta Vrsta { get => vrsta; set => vrsta = value; }
    }
}
