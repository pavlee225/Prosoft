﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class KlasaZaServer
    {
        int id;
        string naziv;
        string tip;
        int godina;
        double dug;

        public int Id { get => id; set => id = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public string Tip { get => tip; set => tip = value; }
        public int Godina { get => godina; set => godina = value; }
        public double Dug { get => dug; set => dug = value; }
    }
}
