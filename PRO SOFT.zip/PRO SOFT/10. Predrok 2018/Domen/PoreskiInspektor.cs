﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class PoreskiInspektor
    {
        public override string ToString()
        {
            return ImePrezime;
        }
        int inspektorID;
        string imePrezime;
        string korisnickoIme;
        string lozinka;

        public int InspektorID { get => inspektorID; set => inspektorID = value; }
        public string ImePrezime { get => imePrezime; set => imePrezime = value; }
        public string KorisnickoIme { get => korisnickoIme; set => korisnickoIme = value; }
        public string Lozinka { get => lozinka; set => lozinka = value; }
    }
}
