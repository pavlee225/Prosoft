﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        Linija linija; 

        public FormaKlijent()
        {
            InitializeComponent();
            k = new Komunikacija();
            if (k.poveziSeNaServer()) this.Text = "Povezan!"; ;
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            linija = new Linija();
            dataGridView1.DataSource = linija.Medjustanice;
            napuniCombo(cmbPocetna);
            napuniCombo(cmbKrajnja);
            napuniCombo(cmbMedjustanica);
        }

        void napuniCombo(ComboBox combo)
        {
            combo.Items.Clear();
            foreach (Stanica s in k.VratiSveStanice())
            {
                combo.Items.Add(s);
            }
            combo.Text = "Odaberite stanicu!";
        }

        private void FormaKlijent_FormClosed(object sender, FormClosedEventArgs e)
        {
            k.Kraj();
        }

        private void cmbPocetna_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                linija.Pocetna = cmbPocetna.SelectedItem as Stanica;
                if (linija.Pocetna.Id == linija.Krajnja.Id)
                {
                    MessageBox.Show("Pocetna i krajnja stanica su iste!");
                    napuniCombo(cmbPocetna);
                    return;

                }
                txtNaziv.Text = linija.Naziv;
            }
            catch (Exception)
            {

                txtNaziv.Clear();
            }
        }

        private void cmbKrajnja_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                linija.Krajnja = cmbKrajnja.SelectedItem as Stanica;
                if (linija.Pocetna.Id == linija.Krajnja.Id)
                {
                    MessageBox.Show("Pocetna i krajnja stanica su iste!");
                    napuniCombo(cmbKrajnja);
                    return;

                }
                txtNaziv.Text = linija.Naziv;
            }
            catch (Exception)
            {

                txtNaziv.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LinijaStanica ls = new LinijaStanica();
            ls.Linija = linija;
            ls.Stanica = cmbMedjustanica.SelectedItem as Stanica;

            try
            {

                if (ls.Stanica.Id == linija.Krajnja.Id || ls.Stanica.Id == linija.Pocetna.Id)
                {
                    MessageBox.Show("Pocetna ili krajnja stanica su iste kao medjustanica!");
                    napuniCombo(cmbMedjustanica);
                    return;

                }
            }
            catch (NullReferenceException)
            {

                MessageBox.Show("Niste odabrali pocetnu ili krajnju stanicu!");
                return;
            }
            catch (Exception){ }


            foreach (LinijaStanica lsi in linija.Medjustanice)
            {
                if (ls.Stanica.Id == lsi.Stanica.Id)
                {
                    MessageBox.Show("Vec ste dodali istu medjustanicu!");
                    return;
                }
            }

            linija.Medjustanice.Add(ls);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int rez = k.sacuvajLiniju(linija);

            if (rez == 0)
            {
                MessageBox.Show("Linija nije sacuvana!");
            }

            if (rez == -1)
            {
                MessageBox.Show("Linija nije sacuvana!\nPostoji ista linija!");
            }

            if (rez == 1)
            {
                MessageBox.Show("Linija je uspesno sacuvana!");
                FormaKlijent_Load(sender, e);
            }
        }
    }
}
