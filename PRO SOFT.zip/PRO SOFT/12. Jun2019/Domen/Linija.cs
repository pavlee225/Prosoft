﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{

    [Serializable]
    public class Linija
    {
        public override string ToString()
        {
            return naziv;
        }

        public Linija()
        {
            medjustanice = new BindingList<LinijaStanica>();
        }

        int id;
        string naziv;
        Stanica pocetna;
        Stanica krajnja;
        BindingList<LinijaStanica> medjustanice;

        public int Id { get => id; set => id = value; }
        public string Naziv { get => pocetna.Naziv+" - "+krajnja.Naziv; set => naziv = value; }
        public Stanica Pocetna { get => pocetna; set => pocetna = value; }
        public Stanica Krajnja { get => krajnja; set => krajnja = value; }
        [Browsable(false)]
        public BindingList<LinijaStanica> Medjustanice { get => medjustanice; set => medjustanice = value; }

        [DisplayName("Medjustanice")]
        public string MedjustaniceString
        {
            get
            {
                string rezultat = "";

                foreach(LinijaStanica ls in medjustanice)
                {
                    rezultat += ls.Stanica.Naziv + ", ";
                }

                return rezultat;
            }
        }
    }
}
