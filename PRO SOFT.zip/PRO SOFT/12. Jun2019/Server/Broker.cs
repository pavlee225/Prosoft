﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using Domen;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void poveziSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=ProSoft-Jun2019;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            poveziSe();
        }

        static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }


        // metode


        public List<Stanica> vratiSveStanice()
        {
            List<Stanica> lista = new List<Stanica>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Stanica";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Stanica s = new Stanica();
                    s.Id = citac.GetInt32(0);
                    s.Naziv = citac.GetString(1);
                    lista.Add(s);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public int vratiSifruLinije()
        {
          
            try
            {
                
                komanda.CommandText = "Select max(LinijaID) from Linija";
                object o = komanda.ExecuteScalar();
                if (o == DBNull.Value) return 1;
                else return Convert.ToInt32(o);
            }
            catch (Exception)
            {

                throw;
            }
          
        }

        public int sacuvajLiniju(Linija l)
        {
           
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                if (proveriLiniju(l)) return -1;

                komanda.CommandText = "Insert into Linija (NazivLinije,POcetnaStanica,KrajnjaStanica) values ('"+l.Naziv+"',"+l.Pocetna.Id+","+l.Krajnja.Id+")";
                komanda.ExecuteNonQuery();

                l.Id = vratiSifruLinije();
                foreach (LinijaStanica ls in l.Medjustanice)
                {
                    komanda.CommandText = "Insert into LinijaStanica values("+l.Id+","+ls.Stanica.Id+")";
                    komanda.ExecuteNonQuery();
                }

                transakcija.Commit();
                return 1;
              
            }
            catch (Exception ex)
            {
                transakcija.Rollback();
                return 0;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public bool proveriLiniju(Linija l)
        {
            List<Linija> isteLinije = new List<Linija>();
            komanda.CommandText = "Select * from Linija where NazivLinije='" + l.Naziv + "'";
            SqlDataReader citac = komanda.ExecuteReader();
            while (citac.Read())
            {
                Linija li = new Linija();
                li.Id = citac.GetInt32(0);
                isteLinije.Add(li);
            }
            citac.Close();

            foreach (Linija li in isteLinije)
            {
                if (proveriMedjustanice(l, li)) return true;
            }
            return false;


        }

        public bool proveriMedjustanice(Linija l, Linija li)
        {
            List<int> listID = new List<int>();
            komanda.CommandText = "Select * from LinijaStanica where LinijaID=" + li.Id + "";
            SqlDataReader citac = komanda.ExecuteReader();
            while (citac.Read())
            {
                listID.Add(citac.GetInt32(1));               
            }
            citac.Close();

            bool postoji = true;
            foreach (LinijaStanica ls in l.Medjustanice)
            {
                if (!listID.Contains(ls.Stanica.Id)) postoji = false;
            }

            foreach (int i in listID)
            {
                bool ima = false;
                foreach (LinijaStanica ls in l.Medjustanice)
                {
                    if (ls.Stanica.Id == i)
                    {
                        ima = true;
                    }
                }

                if (!ima) postoji = false;
            }

            return postoji;


        }
    }
}
