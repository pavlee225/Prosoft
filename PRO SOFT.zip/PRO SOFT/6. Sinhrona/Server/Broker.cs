﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekicija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekicija = new SqlConnection(@"");
            komanda = konekicija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        static Broker instanca;
        public static Broker dajSesiju()
        {
            if(instanca == null)
            {
                instanca = new Broker();
            }
            return instanca;
        }
    }
}
