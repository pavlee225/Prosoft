﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=ProSoft-Mart2020;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public List<Publikacija> vratiSvePublikacije()
        {
            List<Publikacija> lista = new List<Publikacija>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Publikacija";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Publikacija p = new Publikacija();
                    p.Id = citac.GetInt32(0);
                    p.Naziv = citac.GetString(1);
                    lista.Add(p);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiIDIzdanja()
        {
            try
            {
                komanda.CommandText = "Select max(IzdanjeID) from Izdanje";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {
                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public string sacuvajIzdanje(Izdanje i)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);
                i.Id = vratiIDIzdanja();

                if(proveraIzdanja(i.Datum, i.Broj))
                {
                    transakcija.Rollback();
                    return "Vec postoji izdanje publikacije za izabrani datum ili broj!";
                }

                komanda.CommandText = "Insert into Izdanje values(" + i.Id + ",'" + i.Datum.ToString("yyyy-MM-dd") + "'," + i.Broj + "," + i.Publikacija.Id + ")";
                komanda.ExecuteNonQuery();
                
                foreach(Vest v in i.ListaVesti)
                {
                    komanda.CommandText = "Insert into Vest values(" + i.Id + "," + v.Rb + ",'" + v.Naslov + "','" + v.Tekst + "')";
                    komanda.ExecuteNonQuery();
                }

                

                transakcija.Commit();
                return "Sacuvano!";
            }
            catch (Exception)
            {
                transakcija.Rollback();
                return "Nije sacuvano!";
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Izdanje> vratiSvaIzdanja()
        {
            List<Izdanje> lista = new List<Izdanje>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Izdanje";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Izdanje i = new Izdanje();
                    i.Datum = citac.GetDateTime(1);
                    i.Broj = citac.GetInt32(2);
                    lista.Add(i);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        private bool proveraIzdanja(DateTime datum, int broj)
        {
            List<Izdanje> lista = new List<Izdanje>();
            lista = vratiSvaIzdanja();

            foreach(Izdanje izd in lista)
            {
                if(izd.Datum == datum || izd.Broj == broj)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
