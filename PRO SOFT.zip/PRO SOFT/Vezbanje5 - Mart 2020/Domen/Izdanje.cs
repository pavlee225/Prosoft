﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Izdanje
    {
        public Izdanje()
        {
            listaVesti = new BindingList<Vest>();
        }

        int id;
        DateTime datum;
        int broj;
        Publikacija publikacija;
        BindingList<Vest> listaVesti;

        public int Id { get => id; set => id = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        public int Broj { get => broj; set => broj = value; }
        public Publikacija Publikacija { get => publikacija; set => publikacija = value; }
        public BindingList<Vest> ListaVesti { get => listaVesti; set => listaVesti = value; }
    }
}
