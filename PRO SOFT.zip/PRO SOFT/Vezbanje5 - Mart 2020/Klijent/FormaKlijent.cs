﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        Izdanje izdanje;
        public FormaKlijent()
        {
            InitializeComponent();
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }

            cmbPublikacija.DataSource = k.vratiPublikacije();
            izdanje = new Izdanje();
            dataGridView1.DataSource = izdanje.ListaVesti;
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            Vest v = new Vest();
            try
            {
                v.Publikacija = cmbPublikacija.SelectedItem as Publikacija;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali publikaciju!");
                return;
            }
            
            v.Rb = izdanje.ListaVesti.Count + 1; //videcemo da li je dobro

            izdanje.ListaVesti.Add(v);
        }

        private void btnUkloni_Click(object sender, EventArgs e)
        {
            try
            {
                Vest v = dataGridView1.CurrentRow.DataBoundItem as Vest;
                izdanje.ListaVesti.Remove(v);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali vest za brisanje!");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                izdanje.Publikacija = cmbPublikacija.SelectedItem as Publikacija;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali publikaciju!");
                return;
            }

            try
            {
                izdanje.Broj = Convert.ToInt32(txtBroj.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste lepo upisali broj!");
                return;
            }

            try
            {
                izdanje.Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste lepo upisali datum!");
                return;
            }
            
            if(izdanje.ListaVesti.Count < 1)
            {
                MessageBox.Show("Izdanje mora imati barem jednu vest!");
                return;
            }

            foreach(Vest ve in izdanje.ListaVesti)
            {
                if(ve.Naslov.Length > 100)
                {
                    MessageBox.Show("Predugacak naslov!");
                    return;
                }
            }
            
            string poruka = k.sacuvajIzdanje(izdanje);
            MessageBox.Show(poruka);
        }
    }
}
