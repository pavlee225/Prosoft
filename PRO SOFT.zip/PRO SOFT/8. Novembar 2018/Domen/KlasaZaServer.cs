﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public class KlasaZaServer
    {
        string domacin;
        string gost;
        DateTime datum;

        public string Domacin { get => domacin; set => domacin = value; }
        public string Gost { get => gost; set => gost = value; }
        [Browsable(false)]
        public DateTime Datum { get => datum; set => datum = value; }

        //lepsi prikaz
        [DisplayName("Datum")]
        public string Dat {
            get { return datum.ToString("dd.MM.yyyy"); }
        }
    }
}
