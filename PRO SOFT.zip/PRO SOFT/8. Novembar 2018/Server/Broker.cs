﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Nov2018;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public List<Reprezentacija> vratiSveReprezentacije()
        {
            List<Reprezentacija> lista = new List<Reprezentacija>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Reprezentacija";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Reprezentacija r = new Reprezentacija();
                    r.Id = citac.GetInt32(0);
                    r.Naziv = citac.GetString(1);
                    lista.Add(r);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiSifruPara()
        {
            try
            {
                komanda.CommandText = "Select max(ID) from Par";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {
                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public string sacuvajParove(List<Par> lista)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("",konekcija,transakcija);
                foreach(Par p in lista)
                {
                    //dodatak
                    if (proveriPar(p))
                    {
                        transakcija.Rollback();
                        return "Par vec postoji!";
                    }

                    if (proveriPreyentaciju(p))
                    {
                        transakcija.Rollback();
                        return "Neko vec igra istog dana!";
                    }

                    if (p.Domacin.Id == p.Gost.Id)
                    {
                        transakcija.Rollback();
                        return p.Domacin.Naziv +"igra sam sa sobom!";
                    }

                    //normalno:
                    p.Id = vratiSifruPara();
                    komanda.CommandText = "Insert into Par values("+p.Id+","+p.Domacin.Id+","+p.Gost.Id+",'"+p.Datum.ToString("yyyy-MM-dd")+"'";
                    komanda.ExecuteNonQuery();
                }
                transakcija.Commit();
                return "Sacuvano!";
            }
            catch (Exception)
            {
                transakcija.Rollback();
                return "Nije sacuvano!";
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool proveriPar(Par p)
        {
            
            try
            {
                komanda.CommandText = "Select * from Par where cast(Datum as date)=cast('"+p.Datum.ToString("yyyy-MM-dd")+"' as date) and Domacin="+p.Domacin.Id+" and Gost="+p.Gost.Id+"";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    citac.Close();
                    return true;
                }
                return false;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool proveriPreyentaciju(Par p)
        {

            try
            {
                komanda.CommandText = "Select * from Par where cast(Datum as date)=cast('" + p.Datum.ToString("yyyy-MM-dd") + "' as date) and (Domacin=" + p.Domacin.Id + " or Gost=" + p.Gost.Id + " or Gost=" + p.Domacin.Id + " or Domacin=" + p.Gost.Id + ")";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    citac.Close();
                    return true;
                }
                return false;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<KlasaZaServer> vratiKlasuZaServer(string uslov)
        {
            List<KlasaZaServer> lista = new List<KlasaZaServer>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "SELECT d.Naziv, g.Naziv, p.Datum from Par p inner join Reprezentacija d on p.Domacin = d.ID inner join Reprezentacija g on p.Gost= g.ID" +uslov;
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    KlasaZaServer k = new KlasaZaServer();
                    k.Domacin = citac.GetString(0);
                    k.Gost = citac.GetString(1);
                    k.Datum = citac.GetDateTime(2);
                    lista.Add(k);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}

