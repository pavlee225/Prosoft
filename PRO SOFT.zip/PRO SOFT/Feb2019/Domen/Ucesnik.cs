﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Ucesnik
    {
        Korisnik korisnik;
        Dogadjaj dogadjaj;

        public Korisnik Korisnik
        {
            get
            {
                return korisnik;
            }

            set
            {
                korisnik = value;
            }
        }
        [Browsable(false)]
        public Dogadjaj Dogadjaj
        {
            get
            {
                return dogadjaj;
            }

            set
            {
                dogadjaj = value;
            }
        }
    }
}
