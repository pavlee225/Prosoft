﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public class UlogovaniKorisnik
    {
        public override bool Equals(object obj)
        {
            var u = obj as UlogovaniKorisnik;
            return (u!=null && u.Korisnik!=null&&u.Korisnik.Id==this.Korisnik.Id);
        }

        public NetworkStream Tok;
        public Korisnik Korisnik;
    }
}
