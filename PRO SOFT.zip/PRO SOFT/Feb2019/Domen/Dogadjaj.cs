﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Status { NijeMenjano, Dodat, Izmenjen, Obrisan  }
    public enum TipDogadjaja { Sastanak, Podsetnik, Rodjendan, Godisnjica }
    [Serializable]
    public class Dogadjaj
    {
        public override string ToString()
        {
            return Naziv;
        }

        public Dogadjaj()
        {
            ListaUcesnika = new BindingList<Ucesnik>();
        }

        int id;
        string naziv;
        DateTime datumOD;
        DateTime datumDO;
        string lokacija;
        TipDogadjaja tipDogadjaja;
        Korisnik korisnik;
        BindingList<Ucesnik> listaUcesnika;
        Status status;

        [Browsable(false)]
        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Naziv
        {
            get
            {
                return naziv;
            }

            set
            {
                naziv = value;
            }
        }

        public DateTime DatumOD
        {
            get
            {
                return datumOD;
            }

            set
            {
                datumOD = value;
            }
        }

        public DateTime DatumDO
        {
            get
            {
                return datumDO;
            }

            set
            {
                datumDO = value;
            }
        }

        public string Lokacija
        {
            get
            {
                return lokacija;
            }

            set
            {
                lokacija = value;
            }
        }

        public TipDogadjaja TipDogadjaja
        {
            get
            {
                return tipDogadjaja;
            }

            set
            {
                tipDogadjaja = value;
            }
        }
        [Browsable(false)]

        public Korisnik Korisnik
        {
            get
            {
                return korisnik;
            }

            set
            {
                korisnik = value;
            }
        }

        public BindingList<Ucesnik> ListaUcesnika
        {
            get
            {
                return listaUcesnika;
            }

            set
            {
                listaUcesnika = value;
            }
        }

        public string Ucesnici
        {
            get
            {
                string prikaz = "";

                foreach (Ucesnik u in listaUcesnika) prikaz += u.Korisnik.ToString() + ", ";

                return prikaz;
            }           
        }

        public Status Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }
    }
}
