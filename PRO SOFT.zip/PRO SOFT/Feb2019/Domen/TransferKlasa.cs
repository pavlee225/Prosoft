﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Operacije { Kraj=1,
        Login = 2,
        VratiDogadjaje = 3,
        VratiKorinsike = 4,
        SacuvajIzmene = 5,
        Poruka = 6
    }
    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public Object TransferObjekat;
        public Object Rezultat;
        public string Poruka;
        public bool Zabrana;
    }
}
