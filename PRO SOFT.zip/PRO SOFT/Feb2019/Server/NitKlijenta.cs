﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Server
{
    class NitKlijenta
    {
        private NetworkStream tok;
        BinaryFormatter formater;
        int brPokusaja = 0;
        UlogovaniKorisnik u;
        public NitKlijenta(NetworkStream tok)
        {
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradiKlijenta;
            new Thread(ts).Start();

        }


        void obradiKlijenta()
        {
            try
            {
                int a = 0;
                while (a != (int)Operacije.Kraj)
                {
                    TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;
                    switch (transfer.Operacija)
                    {

                        case Operacije.Login:
                            
                            

                            Korisnik k= Broker.dajSesiju().login(transfer.TransferObjekat as Korisnik);
                            u = new UlogovaniKorisnik();
                            u.Tok = tok;
                            u.Korisnik = k;
                            if (k == null||Server.listaUlogovanih.Contains(u))
                            {
                                brPokusaja++;
                                transfer.Poruka = "Neuspelo logovanje ili ste vec ulogovani!\nOstalo je jos "+(Server.MAX_BR_LOGOVANJA-brPokusaja)+" pokusaja!";
                                transfer.Rezultat = null;
                                if (brPokusaja == Server.MAX_BR_LOGOVANJA)
                                {
                                    transfer.Zabrana = true;
                                }
                            }
                            else
                            {
                                brPokusaja = 0;
                              
                                Server.listaUlogovanih.Add(u);
                                transfer.Rezultat = k;
                            }

                           

                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.VratiDogadjaje:
                            transfer.Rezultat = Broker.dajSesiju().vratiDogadjajeZaKorisnika(transfer.TransferObjekat as Korisnik);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.VratiKorinsike:
                            transfer.Rezultat = Broker.dajSesiju().vratiKorisnikeOsim(transfer.TransferObjekat as Korisnik);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.SacuvajIzmene:
                            transfer.Rezultat = Broker.dajSesiju().sacuvajDogadjaje(transfer.TransferObjekat as List<Dogadjaj>);
                            formater.Serialize(tok, transfer);

                            foreach (UlogovaniKorisnik ul in Server.listaUlogovanih)
                            {
                                List<Dogadjaj> listaD = transfer.TransferObjekat as List<Dogadjaj>;

                                List<Dogadjaj> listaZaSlanje = new List<Dogadjaj>();
                                foreach (Dogadjaj d in listaD)
                                {
                                    bool postoji = false;
                                    foreach (Ucesnik uc in d.ListaUcesnika)
                                    {
                                        if (uc.Korisnik.Id == ul.Korisnik.Id) postoji = true;
                                    }
                                    if (postoji) listaZaSlanje.Add(d);
                                }
                                transfer.Rezultat = listaZaSlanje;
                                transfer.Operacija = Operacije.Poruka;
                                formater.Serialize(ul.Tok, transfer);

                            }


                            break;

                        case Operacije.Kraj:
                            Server.listaTokova.Remove(tok);
                            Server.listaUlogovanih.Remove(u);
                            a = 1;
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception)
            {
                Server.listaTokova.Remove(tok);
                Server.listaUlogovanih.Remove(u);
            }
        }
    }
}
