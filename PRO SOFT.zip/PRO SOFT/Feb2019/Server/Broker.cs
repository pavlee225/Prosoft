﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand  komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=ARSA-PC;Initial Catalog=Feb2019;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }



        public Korisnik login(Korisnik k)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Korisnik where Username='"+k.User+"' and Password='"+k.Pass+"'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    k.Id = citac.GetInt32(0);
                    k.Ime = citac.GetString(1);
                    k.Prezime = citac.GetString(2);

                    citac.Close();
                    return k;
                }
                citac.Close();
                return null;

            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<Dogadjaj> vratiDogadjajeZaKorisnika(Korisnik k)
        {
            List<Dogadjaj> lista = new List<Dogadjaj>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Dogadjaj where KorisnikID="+k.Id+" order by DatumOD asc";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Dogadjaj d = new Dogadjaj();
                    d.Id = citac.GetInt32(0);
                    d.Naziv = citac.GetString(1);
                    d.DatumOD = citac.GetDateTime(2);
                    d.DatumDO = citac.GetDateTime(3);
                    d.Lokacija = citac.GetString(4);
                    d.TipDogadjaja = (TipDogadjaja)Enum.Parse(typeof(TipDogadjaja),citac.GetString(5));
                    d.Korisnik = k;
                    lista.Add(d);
                }
                citac.Close();
                foreach (Dogadjaj d in lista) vratiUcesnikeDogadjaja(d);

                return lista;

            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public void vratiUcesnikeDogadjaja(Dogadjaj d)
        {
          
            try
            {
               
                komanda.CommandText = "Select * from Ucesnik u inner join Korisnik k on u.KorisnikID=k.ID where DogadjajID=" + d.Id + "";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Ucesnik u = new Ucesnik();
                    u.Dogadjaj = d;
                    u.Korisnik = new Korisnik();
                    u.Korisnik.Id = citac.GetInt32(2);
                    u.Korisnik.Ime = citac.GetString(3);
                    u.Korisnik.Prezime = citac.GetString(4);

                    d.ListaUcesnika.Add(u);
                }
                citac.Close();
              

            }
            catch (Exception)
            {

                throw;
            }
          
        }

        public List<Korisnik> vratiKorisnikeOsim(Korisnik k)
        {
            List<Korisnik> lista = new List<Korisnik>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Korisnik where ID<>" + k.Id +" order by Prezime asc";
                SqlDataReader citac = komanda.ExecuteReader();
                while(citac.Read())
                {
                    Korisnik ko = new Korisnik();
                    ko.Id = citac.GetInt32(0);
                    ko.Ime = citac.GetString(1);
                    ko.Prezime = citac.GetString(2);

                    lista.Add(ko);
                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        public int vratiSifruDogadgaja()
        {
            try
            {
                komanda.CommandText = "Select max(Id) from Dogadjaj";
                Object o = komanda.ExecuteScalar();
                if (o == DBNull.Value) return 1;
                else return Convert.ToInt32(o) + 1;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool sacuvajDogadjaje(List<Dogadjaj> lista)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                foreach (Dogadjaj d in lista)
                {
                    switch (d.Status)
                    {                        
                        case Status.Dodat:
                            d.Id = vratiSifruDogadgaja();
                            komanda.CommandText = "Insert into Dogadjaj values(" + d.Id + ",'"+d.Naziv+"','" + d.DatumOD.ToString("MM-dd-yyyy HH:mm") + "','" + d.DatumDO.ToString("MM-dd-yyyy HH:mm") + "', '" + d.Lokacija + "','"+d.TipDogadjaja.ToString()+"'," + d.Korisnik.Id + ")";
                            komanda.ExecuteNonQuery();

                            foreach (Ucesnik u in d.ListaUcesnika)
                            {
                                komanda.CommandText = "Insert into Ucesnik values("+u.Korisnik.Id+","+u.Dogadjaj.Id+")";
                                komanda.ExecuteNonQuery();
                            }

                            break;
                        case Status.Izmenjen:
                            komanda.CommandText = "Update Dogadjaj set Naziv='" + d.Naziv + "', DatumOD='" + d.DatumOD.ToString("MM-dd-yyyy HH:mm") + "', DatumDO='" + d.DatumDO.ToString("MM-dd-yyyy HH:mm") + "', Lokacija='" + d.Lokacija + "', TipDogadjaja='" + d.TipDogadjaja.ToString() + "', KorisnikID=" + d.Korisnik.Id + " where ID="+d.Id+"";
                            komanda.ExecuteNonQuery();

                            komanda.CommandText = "Delete from Ucesnik where DogadjajID="+d.Id+"";
                            komanda.ExecuteNonQuery();

                            foreach (Ucesnik u in d.ListaUcesnika)
                            {
                                komanda.CommandText = "Insert into Ucesnik values(" + u.Korisnik.Id + "," + u.Dogadjaj.Id + ")";
                                komanda.ExecuteNonQuery();
                            }

                            break;

                        case Status.Obrisan:
                            komanda.CommandText = "Delete from Dogadjaj where ID=" + d.Id + "";
                            komanda.ExecuteNonQuery();
                            break;
                        default:
                            break;
                    }

                   

                  
                }
                transakcija.Commit();
                return true;

            }
            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }
    }
}
