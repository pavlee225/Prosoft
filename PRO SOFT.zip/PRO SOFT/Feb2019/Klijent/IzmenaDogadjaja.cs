﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class IzmenaDogadjaja : Form
    {
        private object listaDogadjaja;
        private Dogadjaj dogadjaj;
        private Komunikacija k;
        private Korisnik ko;

        public IzmenaDogadjaja()
        {
            
        }

        public IzmenaDogadjaja(Komunikacija k, Korisnik ko, BindingList<Dogadjaj> listaDogadjaja, Dogadjaj dogadjaj)
        {
            InitializeComponent();
            this.k = k;
            this.ko = ko;
            this.listaDogadjaja = listaDogadjaja;
            this.dogadjaj = dogadjaj;
        }

        private void IzmenaDogadjaja_Load(object sender, EventArgs e)
        {
           
            cmbTip.DataSource = Enum.GetValues(typeof(TipDogadjaja));
           
            cmbKorisnik.DataSource = FormKlijent.listaKorisnika;
            dataGridView1.DataSource = dogadjaj.ListaUcesnika;


            txtNaziv.Text = dogadjaj.Naziv;
            txtLok.Text = dogadjaj.Lokacija;
            txtDAtOd.Text =dogadjaj.DatumOD.ToString("dd.MM.yyyy HH:mm");
            txtDatDo.Text = dogadjaj.DatumDO.ToString("dd.MM.yyyy HH:mm");
            cmbTip.SelectedItem = dogadjaj.TipDogadjaja;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            dogadjaj.Naziv = txtNaziv.Text;

            try
            {
                dogadjaj.DatumOD = DateTime.ParseExact(txtDAtOd.Text, "dd.MM.yyyy HH:mm", null);
                dogadjaj.DatumDO = DateTime.ParseExact(txtDatDo.Text, "dd.MM.yyyy HH:mm", null);
            }
            catch (Exception)
            {

                MessageBox.Show("Ne valjaju datumi!");
                return;
            }


            if (dogadjaj.DatumOD < DateTime.Now)
            {
                MessageBox.Show("Ne moze proslo vreme!");
                return;
            }

            if (dogadjaj.DatumDO < dogadjaj.DatumOD)
            {
                MessageBox.Show("Ne moze unazad!");
                return;
            }

            dogadjaj.TipDogadjaja = (TipDogadjaja)cmbTip.SelectedItem;

            dogadjaj.Lokacija = txtLok.Text;

            if(dogadjaj.Status!=Status.Dodat) dogadjaj.Status = Status.Izmenjen;

            this.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Ucesnik u = new Ucesnik();
            u.Dogadjaj = dogadjaj;
            u.Korisnik = cmbKorisnik.SelectedItem as Korisnik;
            if (u.Korisnik == null)
            {
                MessageBox.Show("Fali ti korisnik!");
                return;
            }

            dogadjaj.ListaUcesnika.Add(u);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Ucesnik u = dataGridView1.CurrentRow.DataBoundItem as Ucesnik;
                dogadjaj.ListaUcesnika.Remove(u);
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali!");
            }
        }
    }
}
