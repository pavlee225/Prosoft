﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public delegate void Delegat(TransferKlasa transfer);
    public partial class FormKlijent : Form
    {
        Komunikacija k;
        private Korisnik ko;
        BindingList<Dogadjaj> listaDogadjaja;
        public static List<Korisnik> listaKorisnika;
      

        public FormKlijent(Korisnik ko, Komunikacija k)
        {
            InitializeComponent();
            this.ko = ko;
            this.k = k;
        }

        private void FormKlijent_Load(object sender, EventArgs e)
        {
            ThreadStart ts = primiPoruku;
            Thread nit = new Thread(ts);
            nit.Start();

            lblKorinsik.Text = ko.ToString();
            k.vratiDogadjaje(ko);
  
            k.vratiKorisnike(ko);


        }


        void primiPoruku()
        {
            while (true)
            {
                TransferKlasa transfer = k.primiPoruku();
                Delegat d = new Delegat(prikaziPoruku);
                Invoke(d, transfer);
               

            }
        }


        void prikaziPoruku(TransferKlasa transfer)
        {
            switch (transfer.Operacija)
            {               
                case Operacije.VratiDogadjaje:
                    listaDogadjaja = new BindingList<Dogadjaj>(transfer.Rezultat as List<Dogadjaj>);
                    dataGridView1.DataSource = listaDogadjaja;

                    break;
                case Operacije.VratiKorinsike:
                    listaKorisnika = transfer.Rezultat as List<Korisnik>;
                    break;
                case Operacije.SacuvajIzmene:
                    if ((bool)transfer.Rezultat)
                    {
                        MessageBox.Show("Sve ok!");
                        
                    }
                    else MessageBox.Show("Nije ok");

                    break;

                case Operacije.Poruka:
                    dataGridView2.DataSource = transfer.Rezultat as List<Dogadjaj>;
                    break;
                default:
                    break;
            }
        }

        private void FormKlijent_FormClosed(object sender, FormClosedEventArgs e)
        {
            k.kraj();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new UnosDogadjaja(k,ko,listaDogadjaja).ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Dogadjaj dogadjaj = dataGridView1.CurrentRow.DataBoundItem as Dogadjaj;

                new IzmenaDogadjaja(k,ko,listaDogadjaja, dogadjaj).ShowDialog();
                dataGridView1.Refresh();
            }
            catch (Exception)
            {

                
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Dogadjaj dogadjaj = dataGridView1.CurrentRow.DataBoundItem as Dogadjaj;
                if (dogadjaj.Status == Status.Dodat) listaDogadjaja.Remove(dogadjaj);
                else  dogadjaj.Status = Status.Obrisan;
                dataGridView1.Refresh();
            }
            catch (Exception)
            {


            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            k.sacuvajIzmene(new List<Dogadjaj>(listaDogadjaja));
         
        }
    }
}
