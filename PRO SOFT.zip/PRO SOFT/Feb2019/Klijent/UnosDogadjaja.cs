﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class UnosDogadjaja : Form
    {
        private Komunikacija k;
        private Korisnik ko;
        private BindingList<Dogadjaj> listaDogadjaja;
        Dogadjaj dogadjaj;

        public UnosDogadjaja()
        {
            
        }

        public UnosDogadjaja(Komunikacija k, Korisnik ko, BindingList<Dogadjaj> listaDogadjaja)
        {
            InitializeComponent();
            this.k = k;
            this.ko = ko;
            this.listaDogadjaja = listaDogadjaja;
        }

        private void UnosDogadjaja_Load(object sender, EventArgs e)
        {
            dogadjaj = new Dogadjaj();
            txtDAtOd.Text = DateTime.Now.ToString("dd.MM.yyyy HH:mm");
            txtDatDo.Text = DateTime.Now.AddHours(1).ToString("dd.MM.yyyy HH:mm");
            cmbTip.DataSource = Enum.GetValues(typeof(TipDogadjaja));

            cmbKorisnik.DataSource = FormKlijent.listaKorisnika;
            dataGridView1.DataSource = dogadjaj.ListaUcesnika;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Ucesnik u = new Ucesnik();
            u.Dogadjaj = dogadjaj;
            u.Korisnik = cmbKorisnik.SelectedItem as Korisnik;
            if (u.Korisnik == null)
            {
                MessageBox.Show("Fali ti korisnik!");
                return;
            }

            dogadjaj.ListaUcesnika.Add(u);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Ucesnik u = dataGridView1.CurrentRow.DataBoundItem as Ucesnik;
                dogadjaj.ListaUcesnika.Remove(u);
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dogadjaj.Korisnik = ko;
            dogadjaj.Naziv = txtNaziv.Text;

            try
            {
                dogadjaj.DatumOD = DateTime.ParseExact(txtDAtOd.Text,"dd.MM.yyyy HH:mm",null);
                dogadjaj.DatumDO = DateTime.ParseExact(txtDatDo.Text, "dd.MM.yyyy HH:mm", null);
            }
            catch (Exception)
            {

                MessageBox.Show("Ne valjaju datumi!");
                return;
            }


            if (dogadjaj.DatumOD < DateTime.Now)
            {
                MessageBox.Show("Ne moze proslo vreme!");
                return;
            }

            if (dogadjaj.DatumDO < dogadjaj.DatumOD)
            {
                MessageBox.Show("Ne moze unazad!");
                return;
            }

            dogadjaj.TipDogadjaja = (TipDogadjaja)cmbTip.SelectedItem;

            dogadjaj.Lokacija = txtLok.Text;

            dogadjaj.Status = Status.Dodat;
            listaDogadjaja.Add(dogadjaj);
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cmbKorisnik_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtNaziv_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDatDo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDAtOd_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLok_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbTip_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
