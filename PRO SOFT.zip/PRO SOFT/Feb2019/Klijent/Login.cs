﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Login : Form
    {
        Komunikacija k;
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

                Korisnik ko = new Korisnik();
                ko.User = txtUser.Text;
                ko.Pass = txtPass.Text;

                TransferKlasa transfer= k.login(ko);
                ko = transfer.Rezultat as Korisnik;

                if (ko == null)
                {
                    MessageBox.Show(transfer.Poruka);

                    if (transfer.Zabrana) this.Close();
                }
                else
                {
                    this.Hide();
                    new FormKlijent(ko, k).ShowDialog();
                    this.Show();
                    Login_Load(sender, e);
                }

            
        }

        private void Login_Load(object sender, EventArgs e)
        {
            k = new Klijent.Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }
        }
    }
}
