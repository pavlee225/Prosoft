﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Rec
    {
        public Rec()
        {
            listaZnacenja = new BindingList<Znacenje>();
        }

        string text;
        Korisnik korisnik;
        BindingList<Znacenje> listaZnacenja;

        [Browsable(false)]
        public string Text { get => text; set => text = value; }
        [Browsable(false)]
        public Korisnik Korisnik { get => korisnik; set => korisnik = value; }

        public string SRB
        {
            get { return text + " (" + korisnik.Username + ")"; }
        }

        public string ENG
        {
            get
            {
                string ispis = "";
                foreach (Znacenje z in listaZnacenja) ispis += z.Text + " (" + z.Korisnik.Username + ");";
                return ispis;
            }
        }

        public BindingList<Znacenje> ListaZnacenja { get => listaZnacenja; set => listaZnacenja = value; }
    }
}
