﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Operacije { Kraj=1,
        Login = 2,
        DodajRec = 3,
        PronadjiRec = 4,
        IzmeniRec = 5
    }

    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public object TransferObjekat; //salje se
        public object Rezultat; //prima se
    }
}
