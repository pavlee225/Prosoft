﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Znacenje
    {
        string text;
        Korisnik korisnik;

        [DisplayName("Znacenje")]
        public string Text { get => text; set => text = value; }
        [Browsable(false)]
        public Korisnik Korisnik { get => korisnik; set => korisnik = value; }
    }
}
