﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class IzmenaReci : Form
    {
        private Komunikacija k;
        private Korisnik ko;

        public IzmenaReci()
        {
            
        }

        public IzmenaReci(Komunikacija k, Korisnik ko)
        {
            InitializeComponent();
            this.k = k;
            this.ko = ko;
        }

        private void IzmenaReci_Load(object sender, EventArgs e)
        {

        }

        Rec r;
        private void btnPronadjiRec_Click(object sender, EventArgs e)
        {
            r = new Rec();
            r.Text = txtRec.Text;
            r = k.pronadjiRec(r);

            if (r == null)
            {
                MessageBox.Show("Rec ne postoji!");
                new UnosReci(k, ko).Show();
            }
            else
            {
                dataGridView1.DataSource = r.ListaZnacenja;
            }
        }

        private void btnDodajRec_Click(object sender, EventArgs e)
        {
            r.Korisnik = ko;
            if (k.izmeniRec(r))
            {
                MessageBox.Show("Izmenio!");
            }
            else
            {
                MessageBox.Show("Nije!");
            }
        }
    }
}
