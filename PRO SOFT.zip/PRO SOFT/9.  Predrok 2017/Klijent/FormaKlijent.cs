﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        private Korisnik ko;

        public FormaKlijent()
        {
            
        }

        public FormaKlijent(Korisnik ko, Komunikacija k)
        {
            InitializeComponent();
            this.ko = ko;
            this.k = k;
            this.Text = ko.ToString();
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                //this.Text = "Povezan!";
            }
        }

        private void uNOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new UnosReci(k, ko).ShowDialog();
        }

        private void iZMENAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new IzmenaReci(k, ko).ShowDialog();
        }

        private void FormaKlijent_FormClosed(object sender, FormClosedEventArgs e)
        {
            k.kraj();
        }
    }
}
