﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class UnosReci : Form
    {
        private Komunikacija k;
        private Korisnik ko;
        Rec rec; //cuva se jak objekat na formi

        public UnosReci()
        {
            
        }

        public UnosReci(Komunikacija k, Korisnik ko)
        {
            InitializeComponent();
            this.k = k;
            this.ko = ko;
        }

        private void UnosReci_Load(object sender, EventArgs e)
        {
            rec = new Rec();
            dataGridView1.DataSource = rec.ListaZnacenja;
        }

        private void btnObrisiZnacenje_Click(object sender, EventArgs e)
        {
            try
            {
                Znacenje z = dataGridView1.CurrentRow.DataBoundItem as Znacenje;
                rec.ListaZnacenja.Remove(z);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali");
            }
        }

        private void btnDodajRec_Click(object sender, EventArgs e)
        {
            rec.Text = txtRec.Text;

            if(rec.Text == "")
            {
                MessageBox.Show("Fali ti rec!");
                return;
            }

            rec.Korisnik = ko; //pokupiti ulogovanog korisnika
            MessageBox.Show(k.dodajRec(rec));
        }
    }
}
