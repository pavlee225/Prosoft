﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void txtLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                Komunikacija k = new Klijent.Komunikacija();
                if (k.poveziSeNaServer())
                {
                    Korisnik ko = new Korisnik();
                    ko.Username = txtLogin.Text;

                    ko = k.login(ko);

                    if(ko == null)
                    {
                        MessageBox.Show("Neuspelo logovanje!");
                    }
                    else
                    {
                        new FormaKlijent(ko, k).ShowDialog();
                    }
                }
            }
        }
    }
}
