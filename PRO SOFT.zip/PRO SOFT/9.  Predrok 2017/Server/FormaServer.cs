﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FormaServer : Form
    {
        Server s;
        Timer t;
        public FormaServer()
        {
            InitializeComponent();
        }

        private void FormaServer_Load(object sender, EventArgs e)
        {
            
        }

        private void btnPokreni_Click(object sender, EventArgs e)
        {
            s = new Server();

            if (s.pokreniServer())
            {
                txtStatus.Text = "Server je pokrenut!";
                btnPokreni.Enabled = false;
                btnZaustavi.Enabled = true;

                dataGridView1.DataSource = Broker.dajSesiju().vratiSveReci();
                dataGridView1.Columns[0].Width = 120;

                t = new Timer();
                t.Interval = 2000;
                t.Tick += osvezi;
                t.Start();
            }
        }

        private void osvezi(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Broker.dajSesiju().vratiSveReci();
            dataGridView1.Columns[0].Width = 100;
        }

        private void btnZaustavi_Click(object sender, EventArgs e)
        {
            if (s.zaustaviServer())
            {
                t.Stop();
                txtStatus.Text = "Server nije pokrenut!";
                btnPokreni.Enabled = true;
                btnZaustavi.Enabled = false;
            }
        }
    }
}
