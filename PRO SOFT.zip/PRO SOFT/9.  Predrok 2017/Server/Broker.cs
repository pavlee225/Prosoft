﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Predrok2017;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public List<Rec> vratiSveReci()
        {
            List<Rec> lista = new List<Rec>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Rec";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Rec r = new Rec();
                    r.Text = citac.GetString(0);
                    r.Korisnik = new Korisnik();
                    r.Korisnik.Username = citac.GetString(1);
                    lista.Add(r);
                }
                citac.Close();

                foreach (Rec r in lista) vratiSvaZnacenjaZaRec(r);

                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        private void vratiSvaZnacenjaZaRec(Rec r)
        {
            try
            {
                komanda.CommandText = "Select * from Znacenje where Rec='" + r.Text + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Znacenje z = new Znacenje();
                    z.Text = citac.GetString(1);
                    z.Korisnik = new Korisnik();
                    z.Korisnik.Username = citac.GetString(2);
                    r.ListaZnacenja.Add(z);
                }
                citac.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Korisnik login(Korisnik k)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Korisnik where Username='" + k.Username + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    k.Ime = citac.GetString(0);
                    k.Prezime = citac.GetString(1);
                    citac.Close();
                    return k;
                }
                citac.Close();
                return null;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool postojiRec(Rec r)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Rec where Rec='" + r.Text + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    citac.Close();
                    return true;
                }
                citac.Close();
                return false;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool postojiZnacenje(Rec r, Znacenje z)
        {
            try
            {
                komanda.CommandText = "Select * from Znacenje where Rec='" + r.Text + "' and Znacenje='" + z.Text + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    citac.Close();
                    return true;
                }
                citac.Close();
                return false;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool dodajRec(Rec r)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);
                komanda.CommandText = "Insert into Rec values('" + r.Text + "','" + r.Korisnik.Username + "')";
                komanda.ExecuteNonQuery();

                foreach(Znacenje z in r.ListaZnacenja)
                {
                    komanda.CommandText = "Insert into Znacenje values('" + r.Text + "','" + z.Text + "','" + r.Korisnik.Username + "')";
                    komanda.ExecuteNonQuery();
                }

                transakcija.Commit();
                return true;
            }
            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool dopuniRec(Rec r)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                foreach(Znacenje z in r.ListaZnacenja)
                {
                    if (!postojiZnacenje(r, z))
                    {
                        komanda.CommandText = "Insert into Znacenje values('" + r.Text + "','" + z.Text + "','" + r.Korisnik.Username + "')";
                        komanda.ExecuteNonQuery();
                    }
                }
                transakcija.Commit();
                return true;
            }
            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public Rec pronadjiRec(Rec r)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Rec whereRec='" + r.Text + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    r.Text = citac.GetString(0);
                    r.Korisnik = new Korisnik();
                    r.Korisnik.Username = citac.GetString(1);
                    citac.Close();
                    vratiSvaZnacenjaZaRec(r);
                    return r;
                }
                citac.Close();
                return null;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool izmeniRec(Rec r)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                komanda.CommandText = "Delete from Znacenje where Rec='" + r.Text + "'";
                komanda.ExecuteReader();

                foreach(Znacenje z in r.ListaZnacenja)
                {
                    komanda.CommandText = "Insert int Znacenje values('" + r.Text + "','" + z.Text + "','" + r.Korisnik.Username + "')";
                    komanda.ExecuteNonQuery();
                }
                transakcija.Commit();
                return true;
            }
            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
