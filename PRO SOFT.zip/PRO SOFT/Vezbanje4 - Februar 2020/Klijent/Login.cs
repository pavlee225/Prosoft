﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Login : Form
    {
        Komunikacija k;
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }

            
        }

        private void btnPrijava_Click(object sender, EventArgs e)
        {
            Regruter r = new Regruter();
            r.KorisnickoIme = txtKorisnickoIme.Text;
            r.Lozinka = txtLozinka.Text;
            r = k.login(r);
            if (r == null)
            {
                MessageBox.Show("Neuspelo logovanje!");
            }
            else
            {
                new FormaKlijent(r, k).ShowDialog();
            }
           
        }
    }
}
