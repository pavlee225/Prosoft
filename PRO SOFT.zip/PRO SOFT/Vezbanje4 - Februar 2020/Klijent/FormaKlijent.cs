﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        private Regruter r;
        BindingList<Intervju> lista;
        public FormaKlijent()
        {
            
        }

        public FormaKlijent(Regruter r, Komunikacija k)
        {
            InitializeComponent();
            this.r = r;
            this.k = k;
        }

        void popuniVozackeDozvole()
        {
            List<string> lista = new List<string>();
            lista.Add("A");
            lista.Add("B");
            lista.Add("C");
            lista.Add("D");
            cmbVozackaDozvola.DataSource = lista;
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            cmbKandidat.DataSource = k.vratiKandidate();
            popuniVozackeDozvole();
            lista = new BindingList<Intervju>(); 
            dataGridView1.DataSource = lista;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Intervju i = new Intervju();

            i.Regruter = r;

            try
            {
                i.Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste dobro uneli datum!");
                return;
            }

            try
            {
                i.Kandidat = cmbKandidat.SelectedItem as Kandidat;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali kandidata!");
                return;
            }

            i.Opis = txtOpis.Text;
            if (i.Opis == "")
            {
                MessageBox.Show("Niste uneli opis!");
                return;
            }

            try
            {
                i.BrojPoenaTest = Convert.ToInt32(txtBrojPoena.Text); 
            }
            catch (Exception)
            {
                MessageBox.Show("Niste dobro uneli broj poena!");
                return;
            }

            if(i.BrojPoenaTest < 0 || i.BrojPoenaTest > 100)
            {
                MessageBox.Show("Broj poena mora biti u opsegu [0,100].");
                return;
            }

            try
            {
                i.VozackaDozvola = cmbVozackaDozvola.SelectedItem as string;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali vozacku dozvolu");
                return;
            }

            if(cbDa.Checked && cbNe.Checked)
            {
                MessageBox.Show("Odabrali ste i da i ne!");
                return;
            }

            if(!cbDa.Checked && !cbNe.Checked)
            {
                MessageBox.Show("Niste odabrali ni da ni ne!");
                return;
            }

            if (cbDa.Checked)
            {
                i.PrethodnoIskustvo = true;
            }
            else
            {
                i.PrethodnoIskustvo = false;
            }

            foreach(Intervju iz in lista)
            {
                if(iz.Kandidat.Id == i.Kandidat.Id && iz.Datum.Day == i.Datum.Day)
                {
                    MessageBox.Show("Jedan kandidat moze biti intervjuisan samo jednom u toku jednog dana!");
                    return;
                }
            }

            lista.Add(i);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(lista.Count < 1)
            {
                MessageBox.Show("Mora biti unet bar jedan intervju!");
                return;
            }

            string poruka = k.sacuvajIntervjue(new List<Intervju>(lista));
            MessageBox.Show(poruka);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Intervju i = dataGridView1.CurrentRow.DataBoundItem as Intervju;
                lista.Remove(i);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali");
            }
        }
    }
}
