﻿namespace Klijent
{
    partial class FormaKlijent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbVozackaDozvola = new System.Windows.Forms.ComboBox();
            this.cmbKandidat = new System.Windows.Forms.ComboBox();
            this.txtDatum = new System.Windows.Forms.TextBox();
            this.txtOpis = new System.Windows.Forms.TextBox();
            this.txtBrojPoena = new System.Windows.Forms.TextBox();
            this.cbDa = new System.Windows.Forms.CheckBox();
            this.cbNe = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kandidat:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prethodno iskustvo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Vozacka dozvola:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Broj poena na testu:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Opis:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Datum (dd.MM.yyyy):";
            // 
            // cmbVozackaDozvola
            // 
            this.cmbVozackaDozvola.FormattingEnabled = true;
            this.cmbVozackaDozvola.Location = new System.Drawing.Point(119, 115);
            this.cmbVozackaDozvola.Name = "cmbVozackaDozvola";
            this.cmbVozackaDozvola.Size = new System.Drawing.Size(245, 21);
            this.cmbVozackaDozvola.TabIndex = 6;
            // 
            // cmbKandidat
            // 
            this.cmbKandidat.FormattingEnabled = true;
            this.cmbKandidat.Location = new System.Drawing.Point(119, 6);
            this.cmbKandidat.Name = "cmbKandidat";
            this.cmbKandidat.Size = new System.Drawing.Size(245, 21);
            this.cmbKandidat.TabIndex = 7;
            // 
            // txtDatum
            // 
            this.txtDatum.Location = new System.Drawing.Point(119, 34);
            this.txtDatum.Name = "txtDatum";
            this.txtDatum.Size = new System.Drawing.Size(245, 20);
            this.txtDatum.TabIndex = 8;
            // 
            // txtOpis
            // 
            this.txtOpis.Location = new System.Drawing.Point(119, 58);
            this.txtOpis.Name = "txtOpis";
            this.txtOpis.Size = new System.Drawing.Size(245, 20);
            this.txtOpis.TabIndex = 9;
            // 
            // txtBrojPoena
            // 
            this.txtBrojPoena.Location = new System.Drawing.Point(119, 88);
            this.txtBrojPoena.Name = "txtBrojPoena";
            this.txtBrojPoena.Size = new System.Drawing.Size(245, 20);
            this.txtBrojPoena.TabIndex = 10;
            // 
            // cbDa
            // 
            this.cbDa.AutoSize = true;
            this.cbDa.Location = new System.Drawing.Point(119, 142);
            this.cbDa.Name = "cbDa";
            this.cbDa.Size = new System.Drawing.Size(40, 17);
            this.cbDa.TabIndex = 11;
            this.cbDa.Text = "Da";
            this.cbDa.UseVisualStyleBackColor = true;
            // 
            // cbNe
            // 
            this.cbNe.AutoSize = true;
            this.cbNe.Location = new System.Drawing.Point(205, 142);
            this.cbNe.Name = "cbNe";
            this.cbNe.Size = new System.Drawing.Size(40, 17);
            this.cbNe.TabIndex = 12;
            this.cbNe.Text = "Ne";
            this.cbNe.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 173);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Dodaj intervju";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(218, 173);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(146, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "Obrisi intervju";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(15, 308);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(349, 23);
            this.button3.TabIndex = 15;
            this.button3.Text = "Sacuvaj intervjue";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 203);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(349, 99);
            this.dataGridView1.TabIndex = 16;
            // 
            // FormaKlijent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 343);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cbNe);
            this.Controls.Add(this.cbDa);
            this.Controls.Add(this.txtBrojPoena);
            this.Controls.Add(this.txtOpis);
            this.Controls.Add(this.txtDatum);
            this.Controls.Add(this.cmbKandidat);
            this.Controls.Add(this.cmbVozackaDozvola);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormaKlijent";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormaKlijent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbVozackaDozvola;
        private System.Windows.Forms.ComboBox cmbKandidat;
        private System.Windows.Forms.TextBox txtDatum;
        private System.Windows.Forms.TextBox txtOpis;
        private System.Windows.Forms.TextBox txtBrojPoena;
        private System.Windows.Forms.CheckBox cbDa;
        private System.Windows.Forms.CheckBox cbNe;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

