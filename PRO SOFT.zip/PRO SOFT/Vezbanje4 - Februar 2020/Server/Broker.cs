﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=ProSoft-Februar2020;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public Regruter login(Regruter r)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Regruter where KorisnickoIme='" + r.KorisnickoIme + "' and Lozinka='"+r.Lozinka+"'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    r.Id = citac.GetInt32(0);
                    r.ImePrezime = citac.GetString(1);
                    citac.Close();
                    return r;
                }
                citac.Close();
                return null;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Kandidat> vratiSveKandidate()
        {
            List<Kandidat> lista = new List<Kandidat>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Kandidat";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Kandidat k = new Kandidat();
                    k.Id = citac.GetInt32(0);
                    k.ImePrezime = citac.GetString(1);
                    k.StrucnaSprema = citac.GetString(2);
                    k.Zanimanje = citac.GetString(3);
                    lista.Add(k);
                }
                citac.Close();

                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }


        public int vratiIDIntervjua()
        {
            try
            {
                komanda.CommandText = "Select max(IntervjuID) from Intervju";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {
                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        int getBit(bool b)
        {
            if (b) return 1; //true
            else return 0; //false
        }

        public string sacuvajIntervjue(List<Intervju> lista)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);
                foreach (Intervju i in lista)
                {
                    //i.Id = vratiIDIntervjua();
                    komanda.CommandText = "Insert into Intervju (Datum,Opis,BrojPoenaTest,VozackaDozvola, PrethodnoIskustvo,KandidatID, RegruterID) values('" + i.Datum.ToString("yyyy-MM-dd") + "','" + i.Opis + "'," + i.BrojPoenaTest + ",'"+i.VozackaDozvola+"',"+ getBit(i.PrethodnoIskustvo) +","+i.Kandidat.Id+","+i.Regruter.Id+")";
                    komanda.ExecuteNonQuery();
                }
                transakcija.Commit();
                return "Sacuvano!";
            }
            catch (Exception ex)
            {
                transakcija.Rollback();
                System.Windows.Forms.MessageBox.Show(ex.Message);
                return "Nije sacuvano!";
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
