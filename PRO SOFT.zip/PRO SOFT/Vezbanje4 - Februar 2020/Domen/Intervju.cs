﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Intervju
    {
        int id;
        DateTime datum;
        string opis;
        float brojPoenaTest;
        string vozackaDozvola;
        bool prethodnoIskustvo;
        Kandidat kandidat;
        Regruter regruter;

        public Kandidat Kandidat { get => kandidat; set => kandidat = value; }
        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        [Browsable(false)]
        public string Opis { get => opis; set => opis = value; }
        [DisplayName("Broj poena")]
        public float BrojPoenaTest { get => brojPoenaTest; set => brojPoenaTest = value; }
        [DisplayName("Vozacka dozvola")]
        public string VozackaDozvola { get => vozackaDozvola; set => vozackaDozvola = value; }
        [DisplayName("Prethodno iskustvo")]
        public bool PrethodnoIskustvo { get => prethodnoIskustvo; set => prethodnoIskustvo = value; }
        [Browsable(false)]
        public Regruter Regruter { get => regruter; set => regruter = value; }
    }
}
