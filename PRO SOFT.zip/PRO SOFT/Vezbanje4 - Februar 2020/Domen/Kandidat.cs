﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Kandidat
    {
        public override string ToString()
        {
            return imePrezime;
        }

        int id;
        string imePrezime;
        string strucnaSprema;
        string zanimanje;

        public int Id { get => id; set => id = value; }
        public string ImePrezime { get => imePrezime; set => imePrezime = value; }
        public string StrucnaSprema { get => strucnaSprema; set => strucnaSprema = value; }
        public string Zanimanje { get => zanimanje; set => zanimanje = value; }
    }
}
