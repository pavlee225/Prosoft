﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FormaServer : Form
    {
        Server s;
        Timer t;
        public FormaServer()
        {
            InitializeComponent();
        }

        private void FormaServer_Load(object sender, EventArgs e)
        {
            s = new Server();
            if (s.pokreniServer())
            {
                this.Text = "Server je pokrenut!";

                t = new Timer();
                t.Interval = 5000;
                t.Tick += osvezi;
                t.Start();
            }

            cbSud.DataSource = Broker.dajSesiju().vratiSudove();
            cbTipSpora.DataSource = Broker.dajSesiju().vratiSporove();
        }

        private void osvezi(object sender, EventArgs e)
        {
            string uslov = "";
            dataGridView1.DataSource = Broker.dajSesiju().vratiZaServer();
            if (checkSud.Checked)
            {
                uslov=" where s.Naziv='"+cbSud.SelectedItem.ToString()+"'";
                dataGridView1.DataSource = Broker.dajSesiju().vratiZaUslov(uslov);
            }

            if (checkTipSpora.Checked)
            {
                uslov = " where ts.Naziv='" + cbTipSpora.SelectedItem.ToString() + "'";
                dataGridView1.DataSource = Broker.dajSesiju().vratiZaUslov(uslov);
            }

            if (checkSud.Checked && checkTipSpora.Checked)
            {
                uslov = " where s.Naziv='" + cbSud.SelectedItem.ToString() + "' and ts.Naziv='" + cbTipSpora.SelectedItem.ToString() + "'";
                dataGridView1.DataSource = Broker.dajSesiju().vratiZaUslov(uslov);
            }

        }
    }
}
