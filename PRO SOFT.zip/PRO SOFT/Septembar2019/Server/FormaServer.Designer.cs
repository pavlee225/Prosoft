﻿namespace Server
{
    partial class FormaServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cbTipSpora = new System.Windows.Forms.ComboBox();
            this.cbSud = new System.Windows.Forms.ComboBox();
            this.checkTipSpora = new System.Windows.Forms.CheckBox();
            this.checkSud = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.cbTipSpora);
            this.groupBox1.Controls.Add(this.cbSud);
            this.groupBox1.Controls.Add(this.checkTipSpora);
            this.groupBox1.Controls.Add(this.checkSud);
            this.groupBox1.Location = new System.Drawing.Point(13, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(690, 364);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Izvestaj";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(26, 155);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(608, 192);
            this.dataGridView1.TabIndex = 4;
            // 
            // cbTipSpora
            // 
            this.cbTipSpora.FormattingEnabled = true;
            this.cbTipSpora.Location = new System.Drawing.Point(233, 79);
            this.cbTipSpora.Name = "cbTipSpora";
            this.cbTipSpora.Size = new System.Drawing.Size(401, 24);
            this.cbTipSpora.TabIndex = 3;
            // 
            // cbSud
            // 
            this.cbSud.FormattingEnabled = true;
            this.cbSud.Location = new System.Drawing.Point(233, 34);
            this.cbSud.Name = "cbSud";
            this.cbSud.Size = new System.Drawing.Size(401, 24);
            this.cbSud.TabIndex = 2;
            // 
            // checkTipSpora
            // 
            this.checkTipSpora.AutoSize = true;
            this.checkTipSpora.Location = new System.Drawing.Point(16, 82);
            this.checkTipSpora.Name = "checkTipSpora";
            this.checkTipSpora.Size = new System.Drawing.Size(131, 21);
            this.checkTipSpora.TabIndex = 1;
            this.checkTipSpora.Text = "Tip spora (filter)";
            this.checkTipSpora.UseVisualStyleBackColor = true;
            // 
            // checkSud
            // 
            this.checkSud.AutoSize = true;
            this.checkSud.Location = new System.Drawing.Point(16, 34);
            this.checkSud.Name = "checkSud";
            this.checkSud.Size = new System.Drawing.Size(96, 21);
            this.checkSud.TabIndex = 0;
            this.checkSud.Text = "Sud (filter)";
            this.checkSud.UseVisualStyleBackColor = true;
            // 
            // FormaServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 389);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormaServer";
            this.Text = "[FON] Izvestaj o predmetima - Server";
            this.Load += new System.EventHandler(this.FormaServer_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cbTipSpora;
        private System.Windows.Forms.ComboBox cbSud;
        private System.Windows.Forms.CheckBox checkTipSpora;
        private System.Windows.Forms.CheckBox checkSud;
    }
}

