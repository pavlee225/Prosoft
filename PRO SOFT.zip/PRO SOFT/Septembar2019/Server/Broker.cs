﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlConnection konekcija;
        SqlCommand komanda;
        SqlTransaction transakcija;

        public void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=MILICIN\SQLEXPRESS;Initial Catalog=ProSoft-Septembar2019;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        public Broker()
        {
            konektujSe();
        }

        static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca==null)
            {
                instanca = new Broker();
            }
            return instanca;
        }

        public List<Sud> vratiSudove()
        {
            List<Sud> lista = new List<Sud>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Sud";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    Sud s = new Sud();

                    s.Id = citac.GetInt32(0);
                    s.Naziv = citac.GetString(1);
                    s.Adresa = citac.GetString(2);

                    lista.Add(s);
                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<TipSpora> vratiSporove()
        {
            List<TipSpora> lista = new List<TipSpora>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from TipSpora";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    TipSpora s = new TipSpora();

                    s.Id = citac.GetInt32(0);
                    s.Naziv = citac.GetString(1);

                    lista.Add(s);
                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public int vratiSifruPredmeta()
        {
            try
            {
                komanda.CommandText = "Select max(PredmetID) from Predmet";
                object o = komanda.ExecuteScalar();
                if (o==DBNull.Value)
                {
                    return 1;
                }
                else
                {
                    return Convert.ToInt32(o);
                }

            }
            catch (Exception)
            {

                throw;
            }
         
            
            
            
        }



        public bool sacuvajPredmet(Predmet p)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                p.Status = "Neresen";

                komanda.CommandText = "Insert into Predmet (BrojPredmeta, DatumPrijema, Tuzilac, Tuzeni, PlacenaSudskaTaksa, TipSporaID, SudID, Status) values ("+p.BrojPredmeta+", '"+p.DatumPrijema.ToShortDateString()+"','"+p.Tuzilac+"','"+p.Tuzeni+"',"+Convert.ToInt32(p.PlacenaSudskaTaksa)+", "+p.TipSpora.Id+","+p.Sud.Id+", '"+p.Status+"')";
                komanda.ExecuteNonQuery();

                p.Id = vratiSifruPredmeta();

                foreach (Podnesak pod in p.Podnesci)
                {
                    komanda.CommandText = "Insert into Podnesak values ("+p.Id+","+pod.Rb+", '"+pod.DatumPrijema.ToShortDateString()+"','"+pod.Opis+"', '"+pod.VrstaPodneska+"' )";
                    komanda.ExecuteNonQuery();
                }

                transakcija.Commit();
                return true;
            }
            catch (Exception ex)
            {
                transakcija.Rollback();
                System.Console.WriteLine(ex.Message);
                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<Predmet> vratiZaUslov(string uslov)
        {
            List<Predmet> lista = new List<Predmet>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Predmet p inner join TipSpora ts on p.TipSporaID=ts.TipSporaID inner join Sud s on p.SudID=s.SudID"+uslov;
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    Predmet p = new Predmet();
                    p.Id = citac.GetInt32(0);
                    p.BrojPredmeta = citac.GetString(1);
                    p.DatumPrijema = citac.GetDateTime(2);
                    p.Tuzilac = citac.GetString(3);
                    p.Tuzeni = citac.GetString(4);
                    p.PlacenaSudskaTaksa = (bool)citac.GetValue(5);

                    TipSpora t = new TipSpora();
                    t.Id = citac.GetInt32(9);
                    t.Naziv = citac.GetString(10);
                    p.TipSpora = t;

                    Sud s = new Sud();
                    s.Id = citac.GetInt32(11);
                    s.Naziv = citac.GetString(12);
                    s.Adresa = citac.GetString(13);
                    p.Sud = s;

                    p.Status = citac.GetString(8);

                    lista.Add(p);
                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<Predmet> vratiZaServer()
        {
            List<Predmet> lista = new List<Predmet>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Predmet p inner join TipSpora ts on p.TipSporaID=ts.TipSporaID inner join Sud s on p.SudID=s.SudID";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    Predmet p = new Predmet();
                    p.Id = citac.GetInt32(0);
                    p.BrojPredmeta = citac.GetString(1);
                    p.DatumPrijema = citac.GetDateTime(2);
                    p.Tuzilac = citac.GetString(3);
                    p.Tuzeni = citac.GetString(4);
                    p.PlacenaSudskaTaksa = (bool)citac.GetValue(5);

                    TipSpora t = new TipSpora();
                    t.Id = citac.GetInt32(9);
                    t.Naziv = citac.GetString(10);
                    p.TipSpora = t;

                    Sud s = new Sud();
                    s.Id = citac.GetInt32(11);
                    s.Naziv = citac.GetString(12);
                    s.Adresa = citac.GetString(13);
                    p.Sud = s;

                    p.Status = citac.GetString(8);

                    lista.Add(p);
                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }
    }
}
