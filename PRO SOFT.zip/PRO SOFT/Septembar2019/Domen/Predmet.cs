﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Predmet
    {
        int id;
        string brojPredmeta;
        DateTime datumPrijema;
        string tuzilac;
        string tuzeni;
        bool placenaSudskaTaksa;
        TipSpora tipSpora;
        Sud sud;
        string status;
        BindingList<Podnesak> podnesci;

        [Browsable(false)]
        public int Id { get => id; set => id = value; }     
        [Browsable(false)]
        public DateTime DatumPrijema { get => datumPrijema; set => datumPrijema = value; }
        [Browsable(false)]
        public string Tuzilac { get => tuzilac; set => tuzilac = value; }
        [Browsable(false)]
        public string Tuzeni { get => tuzeni; set => tuzeni = value; }
        [Browsable(false)]
        public bool PlacenaSudskaTaksa { get => placenaSudskaTaksa; set => placenaSudskaTaksa = value; }
        [Browsable(false)]
        public string Status { get => status; set => status = value; }
        public Sud Sud { get => sud; set => sud = value; }
        public TipSpora TipSpora { get => tipSpora; set => tipSpora = value; }
        public string BrojPredmeta { get => brojPredmeta; set => brojPredmeta = value; }
        [Browsable(false)]
        public BindingList<Podnesak> Podnesci { get => podnesci; set => podnesci = value; }
    }
}
