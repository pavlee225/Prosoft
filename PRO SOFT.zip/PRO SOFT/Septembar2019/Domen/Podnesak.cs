﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    
    [Serializable]
    public class Podnesak
    {
        int id;
        int rb;
        DateTime datumPrijema;
        string opis;
        string vrstaPodneska;
        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        public int Rb { get => rb; set => rb = value; }
        public DateTime DatumPrijema { get => datumPrijema; set => datumPrijema = value; }
        public string Opis { get => opis; set => opis = value; }
        public string VrstaPodneska { get => vrstaPodneska; set => vrstaPodneska = value; }
    }
}
