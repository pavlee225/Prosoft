﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Domen;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        Predmet p;
        Podnesak podnesak;
        BindingList<Podnesak> lista = new BindingList<Podnesak>();
        public FormaKlijent()
        {
            InitializeComponent();
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            p = new Predmet();
            if (k.poveziSe())
            {
                this.Text="Povezan!";
            }

            foreach (Sud s in k.vratiSudove())
            {
                cbSud.Items.Add(s);
            }

            foreach (TipSpora ts in k.vratiSporove())
            {
                cbSpor.Items.Add(ts);
            }

            dataGridView1.DataSource = lista;
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            new DodajPodnesak(k, p, lista).ShowDialog();
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                Podnesak p = dataGridView1.CurrentRow.DataBoundItem as Podnesak;
                lista.Remove(p);
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali podnesak za brisanje!");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                p.Sud = cbSud.SelectedItem as Sud;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste izabrali sud!");
                return;
            }

            try
            {
                p.TipSpora = cbSpor.SelectedItem as TipSpora;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste izabrali tip spora!");
                return;
            }

            try
            {
                p.BrojPredmeta = Convert.ToInt32(txtBrPredmeta.Text);
            }
            catch (Exception)
            {

                MessageBox.Show("Niste uneli broj predmeta!");
                return;
            }

            if (txtDatum.Text=="")
            {
                MessageBox.Show("Niste uneli datum!");
                return;
            }

            try
            {
                p.DatumPrijema = Convert.ToDateTime(txtDatum.Text);

            }
            catch (Exception)
            {
                MessageBox.Show("Neispravan format datuma!");
                return;
            }
            
            p.Tuzilac = txtTuzilac.Text;
            if (txtTuzilac.Text=="")
            {
                MessageBox.Show("Niste uneli tuzioca!");
                return;
            }

            p.Tuzeni = txtTuzeni.Text;
            if (txtTuzeni.Text=="")
            {
                MessageBox.Show("Niste uneli tuzenog!");
                return;
            }

            if (rbDa.Checked)
            {
                p.PlacenaSudskaTaksa = true;
            }
            else if (rbNe.Checked)
            {
                p.PlacenaSudskaTaksa = false;
            }
            else
            {
                MessageBox.Show("Niste selektovali da li je placena sudska taksa!");
                return;
            }

            p.Podnesci = lista;

            if (lista.Count<1)
            {
                MessageBox.Show("Predmet mora imati barem jedan podnesak!");
                return;
            }

            if (k.sacuvajPredmet(p))
            {
                MessageBox.Show("Predmet je uspesno sacuvan!");
            }
            else
            {
                MessageBox.Show("Predmet nije sacuvan!");
            }
        }
    }
}
