﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Domen;

namespace Klijent
{
    public partial class DodajPodnesak : Form
    {
        Komunikacija k;
        Podnesak podnesak;
        Predmet p;
        BindingList<Podnesak> lista;
        public DodajPodnesak(Komunikacija k, Predmet pred, BindingList<Podnesak> lista)
        {
            InitializeComponent();
            this.k = k;
            this.p = pred;
            this.lista = lista;
        }

        private void DodajPodnesak_Load(object sender, EventArgs e)
        {

        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            Podnesak pod = new Podnesak();
            pod.Id = p.Id;

            try
            {
                pod.DatumPrijema = Convert.ToDateTime(txtDatum.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Neispravan datum!");
                return;
            }


            if (pod.DatumPrijema < p.DatumPrijema)
                {
                    MessageBox.Show("Datum prijema podneska mora biti veci ili jednak datumu prijema predmeta!");
                    return;
            }
            
            pod.Opis = txtOpis.Text;
            if (pod.Opis=="")
            {
                MessageBox.Show("Niste uneli opis!");
                return;
            }

            try
            {
                pod.VrstaPodneska = cbVrsta.SelectedItem.ToString();
            }
            catch (Exception)
            {

                MessageBox.Show("Niste uneli vrstu!");
                return;
            }

            pod.Rb = lista.Count()+1;
            lista.Add(pod);

            this.Close();
        }
    }
}
