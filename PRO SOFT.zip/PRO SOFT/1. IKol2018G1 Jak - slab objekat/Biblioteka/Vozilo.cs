﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class Vozilo
    {
        public override string ToString()
        {
            return ""+regBroj;
        }

        int id;
        int regBroj; //treba string, ali sam u bazi pogresila i stavila int
        int godina;
        string ime;
        string prezime;
        BindingList<Osiguranje> listaOsiguranja;

        public int Id { get => id; set => id = value; }
        public int RegBroj { get => regBroj; set => regBroj = value; }
        public int Godina { get => godina; set => godina = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public BindingList<Osiguranje> ListaOsiguranja { get => listaOsiguranja; set => listaOsiguranja = value; }

        public Vozilo()
        {
            listaOsiguranja = new BindingList<Osiguranje>();
        }
    }
}
