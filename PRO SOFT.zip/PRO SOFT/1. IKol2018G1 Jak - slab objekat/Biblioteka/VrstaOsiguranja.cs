﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class VrstaOsiguranja
    {
        public override string ToString()
        {
            return naziv;
        }

        int vrstaID;
        string naziv;
        double cena;

        public int VrstaID { get => vrstaID; set => vrstaID = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public double Cena { get => cena; set => cena = value; }
    }
}
