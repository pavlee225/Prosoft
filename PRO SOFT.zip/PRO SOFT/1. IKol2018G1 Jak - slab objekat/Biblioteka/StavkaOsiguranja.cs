﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class StavkaOsiguranja
    {
        int voziloID;
        int godina;
        int id;
        VrstaOsiguranja vrsta;

        [Browsable(false)]
        public int VoziloID { get => voziloID; set => voziloID = value; }
        [Browsable(false)]
        public int Godina { get => godina; set => godina = value; }
        public int Id { get => id; set => id = value; }
        public VrstaOsiguranja Vrsta { get => vrsta; set => vrsta = value; }
        
    }
}
