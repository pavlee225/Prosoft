﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class Osiguranje
    {
        int voziloID;
        int godina;
        DateTime datum;
        double premija;
        Korisnik k;
        BindingList<StavkaOsiguranja> listaStavki;

        public int VoziloID { get => voziloID; set => voziloID = value; }
        public int Godina { get => godina; set => godina = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        public double Premija { get => premija; set => premija = value; }
        public Korisnik K { get => k; set => k = value; }
        public BindingList<StavkaOsiguranja> ListaStavki { get => listaStavki; set => listaStavki = value; }

        public Osiguranje()
        {
            listaStavki = new BindingList<StavkaOsiguranja>();
        }
    }
}
