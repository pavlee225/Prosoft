﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteka;
using Sesija;

namespace KorisnickiInterfejs
{
    public partial class UnosOsiguranja : Form
    {
        private Korisnik k;
        List<VrstaOsiguranja> listaVrsta;
        Osiguranje osiguranje;

        void popuniListu()
        {
            listaVrsta = new List<VrstaOsiguranja>();
            listaVrsta.Add(new VrstaOsiguranja() { VrstaID = 1, Naziv = "Obavezno", Cena = 200 });
            listaVrsta.Add(new VrstaOsiguranja() { VrstaID = 2, Naziv = "Mini kasko", Cena = 300 });
            listaVrsta.Add(new VrstaOsiguranja() { VrstaID = 3, Naziv = "Kasko", Cena = 400 });
            listaVrsta.Add(new VrstaOsiguranja() { VrstaID = 4, Naziv = "Pomoc na putu - Srb", Cena = 500 });
            listaVrsta.Add(new VrstaOsiguranja() { VrstaID = 5, Naziv = "Pomoc - inostranstvo", Cena = 700 });
        }

        public UnosOsiguranja()
        {
            
        }

        public UnosOsiguranja(Korisnik k)
        {
            InitializeComponent();
            this.k = k;
        }

        private void txtDatum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DateTime datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);
                txtDatumDo.Text = datum.AddYears(1).ToString("dd.MM.yyyy");
            }
            catch (Exception)
            {
                txtDatumDo.Clear();
            }
        }

        private void UnosOsiguranja_Load(object sender, EventArgs e)
        {
            cmbVozilo.DataSource = Broker.dajSesiju().vratiSvaVozila();
            popuniListu();
            cmbVrsta.DataSource = listaVrsta;

        }

        private void cmbVozilo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Vozilo v = cmbVozilo.SelectedItem as Vozilo;
                txtGodina.Text = v.Godina.ToString();
                txtVlasnik.Text = v.Ime + " " + v.Prezime;

                osiguranje = new Osiguranje();
                osiguranje.VoziloID = v.Id;
                dgvDonji2.DataSource = osiguranje.ListaStavki;

                dgvGornji1.DataSource = Broker.dajSesiju().vratiSvaOsiguranjaZaVozilo(v);
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void cmbVrsta_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                VrstaOsiguranja v = cmbVrsta.SelectedItem as VrstaOsiguranja;
                txtCena.Text = v.Cena.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            StavkaOsiguranja so = new StavkaOsiguranja();
            so.Id = osiguranje.ListaStavki.Count + 1;
            so.Vrsta = cmbVrsta.SelectedItem as VrstaOsiguranja;
            if(so.Vrsta == null)
            {
                MessageBox.Show("Niste odabrali vrstu osiguranja!");
                return;
            }

            //Validacija - dodavati razlicite vrste osiguranja
            foreach(StavkaOsiguranja s in osiguranje.ListaStavki)
            {
                if(s.Vrsta.VrstaID == so.Vrsta.VrstaID)
                {
                    MessageBox.Show("Vec ste dodali tu vrstu!");
                    return;
                }
            }

            osiguranje.ListaStavki.Add(so);
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                StavkaOsiguranja so = dgvDonji2.CurrentRow.DataBoundItem as StavkaOsiguranja;
                osiguranje.ListaStavki.Remove(so);

                //Resetovanje rednih brojeva
                int i = 1;
                foreach(StavkaOsiguranja s in osiguranje.ListaStavki)
                {
                    s.Id = i;
                    i++;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali!");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                osiguranje.VoziloID = (cmbVozilo.SelectedItem as Vozilo).Id;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali vozilo");
                return;
            }

            try
            {
                osiguranje.Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);

            }
            catch (Exception)
            {
                MessageBox.Show("Nije dobar datum!");
                return;
            }

            osiguranje.Godina = osiguranje.Datum.Year;

            osiguranje.K = k;

            osiguranje.Premija = 0;

            //racunanje premije
            Vozilo v = cmbVozilo.SelectedItem as Vozilo;
            foreach(StavkaOsiguranja so in osiguranje.ListaStavki)
            {
                osiguranje.Premija += so.Vrsta.Cena * (osiguranje.Godina - v.Godina);
            }

            try
            {
                Broker.dajSesiju().sacuvajOsiguranje(osiguranje);
                MessageBox.Show("Sacuvano osiguranje!\nPremija je: "+osiguranje.Premija+" dinara.");
            }
            catch (Exception)
            {
                MessageBox.Show("Nije sacuvano!");
            }

        }
    }
}
