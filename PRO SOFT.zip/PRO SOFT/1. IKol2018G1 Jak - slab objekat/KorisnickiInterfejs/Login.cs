﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public partial class Login : Form
    {
        List<Korisnik> listaKorisnika;
        void popuniListu()
        {
            listaKorisnika = new List<Korisnik>();
            listaKorisnika.Add(new Korisnik { Ime = "Mika", Prezime = "Mikic", Username = "mika", Password = "mika" });
            listaKorisnika.Add(new Korisnik { Ime = "Pera", Prezime = "Peric", Username = "pera", Password = "pera" });
            listaKorisnika.Add(new Korisnik { Ime = "Zika", Prezime = "Zikic", Username = "zika", Password = "zika" });
        }

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            popuniListu();
        }

        int br = 0;
        private void btnLogin_Click(object sender, EventArgs e)
        {
            foreach(Korisnik k in listaKorisnika)
            {
                if(k.Username == txtUser.Text && k.Password == txtPass.Text)
                {
                    new GlavnaForma(k).ShowDialog();
                    return;
                }
            }
            br++;
            if (br == 3)
            {
                MessageBox.Show("Nemate vise pokusaja!");
                btnLogin.Enabled = false;
            }
            else
            {
                MessageBox.Show("Neuspelo logovanje!\nOstalo je jos " + (3 - br) + " pokusaja.");
            }
        }
    }
}
