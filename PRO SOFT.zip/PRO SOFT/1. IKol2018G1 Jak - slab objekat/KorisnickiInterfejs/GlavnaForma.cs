﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteka;

namespace KorisnickiInterfejs
{
    public partial class GlavnaForma : Form
    {
        private Korisnik k;

        public GlavnaForma()
        {
            
        }

        public GlavnaForma(Korisnik k)
        {
            InitializeComponent();
            this.k = k;
            this.Text = k.Ime+" "+k.Prezime;
        }

        private void iGrupaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new UnosOsiguranja(k).ShowDialog();
        }

        private void GlavnaForma_Load(object sender, EventArgs e)
        {

        }
    }
}
