﻿namespace KorisnickiInterfejs
{
    partial class UnosOsiguranja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDatum = new System.Windows.Forms.TextBox();
            this.txtVlasnik = new System.Windows.Forms.TextBox();
            this.txtCena = new System.Windows.Forms.TextBox();
            this.txtGodina = new System.Windows.Forms.TextBox();
            this.txtDatumDo = new System.Windows.Forms.TextBox();
            this.cmbVozilo = new System.Windows.Forms.ComboBox();
            this.cmbVrsta = new System.Windows.Forms.ComboBox();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnObrisi = new System.Windows.Forms.Button();
            this.btnSacuvaj = new System.Windows.Forms.Button();
            this.dgvGornji1 = new System.Windows.Forms.DataGridView();
            this.dgvDonji2 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGornji1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDonji2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Datum:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cena:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Vrsta:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Vlasnik:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Godina:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Vozilo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(257, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Datum do:";
            // 
            // txtDatum
            // 
            this.txtDatum.Location = new System.Drawing.Point(60, 10);
            this.txtDatum.Name = "txtDatum";
            this.txtDatum.Size = new System.Drawing.Size(106, 20);
            this.txtDatum.TabIndex = 7;
            this.txtDatum.TextChanged += new System.EventHandler(this.txtDatum_TextChanged);
            // 
            // txtVlasnik
            // 
            this.txtVlasnik.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtVlasnik.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtVlasnik.Location = new System.Drawing.Point(63, 110);
            this.txtVlasnik.Name = "txtVlasnik";
            this.txtVlasnik.ReadOnly = true;
            this.txtVlasnik.Size = new System.Drawing.Size(178, 20);
            this.txtVlasnik.TabIndex = 8;
            // 
            // txtCena
            // 
            this.txtCena.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCena.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtCena.Location = new System.Drawing.Point(63, 176);
            this.txtCena.Name = "txtCena";
            this.txtCena.ReadOnly = true;
            this.txtCena.Size = new System.Drawing.Size(178, 20);
            this.txtCena.TabIndex = 9;
            // 
            // txtGodina
            // 
            this.txtGodina.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtGodina.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtGodina.Location = new System.Drawing.Point(63, 78);
            this.txtGodina.Name = "txtGodina";
            this.txtGodina.ReadOnly = true;
            this.txtGodina.Size = new System.Drawing.Size(178, 20);
            this.txtGodina.TabIndex = 10;
            // 
            // txtDatumDo
            // 
            this.txtDatumDo.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDatumDo.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtDatumDo.Location = new System.Drawing.Point(319, 6);
            this.txtDatumDo.Name = "txtDatumDo";
            this.txtDatumDo.ReadOnly = true;
            this.txtDatumDo.Size = new System.Drawing.Size(159, 20);
            this.txtDatumDo.TabIndex = 11;
            // 
            // cmbVozilo
            // 
            this.cmbVozilo.FormattingEnabled = true;
            this.cmbVozilo.Location = new System.Drawing.Point(63, 48);
            this.cmbVozilo.Name = "cmbVozilo";
            this.cmbVozilo.Size = new System.Drawing.Size(178, 21);
            this.cmbVozilo.TabIndex = 12;
            this.cmbVozilo.SelectedIndexChanged += new System.EventHandler(this.cmbVozilo_SelectedIndexChanged);
            // 
            // cmbVrsta
            // 
            this.cmbVrsta.FormattingEnabled = true;
            this.cmbVrsta.Location = new System.Drawing.Point(63, 139);
            this.cmbVrsta.Name = "cmbVrsta";
            this.cmbVrsta.Size = new System.Drawing.Size(178, 21);
            this.cmbVrsta.TabIndex = 13;
            this.cmbVrsta.SelectedIndexChanged += new System.EventHandler(this.cmbVrsta_SelectedIndexChanged);
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(110, 213);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(131, 30);
            this.btnDodaj.TabIndex = 14;
            this.btnDodaj.Text = "Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnObrisi
            // 
            this.btnObrisi.Location = new System.Drawing.Point(260, 213);
            this.btnObrisi.Name = "btnObrisi";
            this.btnObrisi.Size = new System.Drawing.Size(131, 30);
            this.btnObrisi.TabIndex = 15;
            this.btnObrisi.Text = "Obrisi";
            this.btnObrisi.UseVisualStyleBackColor = true;
            this.btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);
            // 
            // btnSacuvaj
            // 
            this.btnSacuvaj.Location = new System.Drawing.Point(110, 378);
            this.btnSacuvaj.Name = "btnSacuvaj";
            this.btnSacuvaj.Size = new System.Drawing.Size(281, 30);
            this.btnSacuvaj.TabIndex = 16;
            this.btnSacuvaj.Text = "Sacuvaj";
            this.btnSacuvaj.UseVisualStyleBackColor = true;
            this.btnSacuvaj.Click += new System.EventHandler(this.btnSacuvaj_Click);
            // 
            // dgvGornji1
            // 
            this.dgvGornji1.AllowUserToAddRows = false;
            this.dgvGornji1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGornji1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGornji1.Location = new System.Drawing.Point(260, 42);
            this.dgvGornji1.Name = "dgvGornji1";
            this.dgvGornji1.Size = new System.Drawing.Size(218, 150);
            this.dgvGornji1.TabIndex = 17;
            // 
            // dgvDonji2
            // 
            this.dgvDonji2.AllowUserToAddRows = false;
            this.dgvDonji2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDonji2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDonji2.Location = new System.Drawing.Point(12, 249);
            this.dgvDonji2.Name = "dgvDonji2";
            this.dgvDonji2.Size = new System.Drawing.Size(466, 123);
            this.dgvDonji2.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(172, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "(dd.MM.yyyy)";
            // 
            // UnosOsiguranja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 420);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dgvDonji2);
            this.Controls.Add(this.dgvGornji1);
            this.Controls.Add(this.btnSacuvaj);
            this.Controls.Add(this.btnObrisi);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.cmbVrsta);
            this.Controls.Add(this.cmbVozilo);
            this.Controls.Add(this.txtDatumDo);
            this.Controls.Add(this.txtGodina);
            this.Controls.Add(this.txtCena);
            this.Controls.Add(this.txtVlasnik);
            this.Controls.Add(this.txtDatum);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UnosOsiguranja";
            this.Text = "UnosOsiguranja";
            this.Load += new System.EventHandler(this.UnosOsiguranja_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGornji1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDonji2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDatum;
        private System.Windows.Forms.TextBox txtVlasnik;
        private System.Windows.Forms.TextBox txtCena;
        private System.Windows.Forms.TextBox txtGodina;
        private System.Windows.Forms.TextBox txtDatumDo;
        private System.Windows.Forms.ComboBox cmbVozilo;
        private System.Windows.Forms.ComboBox cmbVrsta;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnObrisi;
        private System.Windows.Forms.Button btnSacuvaj;
        private System.Windows.Forms.DataGridView dgvGornji1;
        private System.Windows.Forms.DataGridView dgvDonji2;
        private System.Windows.Forms.Label label8;
    }
}