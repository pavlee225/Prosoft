﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sesija
{
    public class Broker
    {
        SqlConnection konekcija;
        SqlCommand komanda;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=DESKTOP-0LRIJEF;Initial Catalog=Baza1Kol2018G1;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        //metode
        public List<Vozilo> vratiSvaVozila()
        {
            List<Vozilo> lista = new List<Vozilo>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Vozilo order by Prezime asc";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Vozilo v = new Vozilo();
                    v.Id = citac.GetInt32(0);
                    v.RegBroj = citac.GetInt32(1);
                    v.Godina = citac.GetInt32(2);
                    v.Ime = citac.GetString(3);
                    v.Prezime = citac.GetString(4);
                    lista.Add(v);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {
                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public void sacuvajOsiguranje(Osiguranje o)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                //prvo se cuva jak objekat
                komanda.CommandText = "Insert into Osiguranje values("+o.VoziloID+","+o.Godina+",'"+o.Datum.ToString("yyyy-MM-dd")+"',"+o.Premija+",'"+o.K.Username+"')";
                komanda.ExecuteNonQuery();

                //sad se cuvaju slabi objekti
                foreach(StavkaOsiguranja so in o.ListaStavki)
                {
                    //prepisi kljuceve od jakov
                    so.VoziloID = o.VoziloID;
                    so.Godina = o.Godina;

                    komanda.CommandText = "Insert into StavkaOsiguranja values("+so.VoziloID+","+so.Godina+","+so.Id+","+so.Vrsta.VrstaID+")";
                    komanda.ExecuteNonQuery();
                }
                transakcija.Commit();

            }
            catch (Exception)
            {
                transakcija.Rollback();
                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<Osiguranje> vratiSvaOsiguranjaZaVozilo(Vozilo v)
        {
            List<Osiguranje> lista = new List<Osiguranje>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Osiguranje where IDVozila =" + v.Id + "order by Datum desc";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Osiguranje o = new Osiguranje();
                    o.VoziloID = citac.GetInt32(0);
                    o.Godina = citac.GetInt32(1);
                    o.Datum = citac.GetDateTime(2);
                    o.Premija = Convert.ToDouble(citac.GetValue(3));
                    o.K = new Korisnik();
                    o.K.Username = citac.GetString(4);
                    lista.Add(o);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {
                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }
    }
}
